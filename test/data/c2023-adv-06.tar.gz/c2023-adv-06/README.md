# Tema **ADV**, grupo **adv-06**
-----

## Constituição dos grupos e participação individual global

| NMec | Nome | email | Participação |
|:---:|:---|:---|:---:|
| 108269 | ANDRÉ MIGUEL ANTUNES CARDOSO | andremacardoso@ua.pt | 20.0% |
| 104341 | DIOGO BRANCO ALVES DA SILVA | diogobranco.as@ua.pt | 0.0% |
|  93096 | JOÃO FRANCISCO TEIXEIRA CATARINO | jftcatarino@ua.pt | 0.0% |
| 103440 | MARCO ANTONIO ALVES ALMEIDA | marco.almeida@ua.pt | 0.0% |
| 107263 | TIAGO ALEXANDRE ABREU FIGUEIREDO | tiago.a.figueiredo@ua.pt | 0.0% |

## Estrutura do repositório

- **src** - deve conter todo o código fonte do projeto.

- **doc** -- deve conter toda a documentação adicional a este README.

- **examples** -- deve conter os exemplos ilustrativos das linguagens criadas.

    - Estes exemplos devem conter comentários (no formato aceite pelas linguagens),
      que os tornem auto-explicativos.

## Relatório

- Use esta secção para fazer um relatório sucinto mas explicativo dos objetivos concretizados.

## Contribuições

- O trabalho neste projeto foi distribuído de forma equitativa por todos os membros do grupo.
- Foi considerada uma partiçao do projeto em 5 partes:
    - **Parte 1** - Definição da linguagem ADV
    - **Parte 2 & 3** - Implementação do analisador semântico
    - **Parte 4 & 5** - Geração de código intermédio
- Sendo que cada membro ficou responsável por 1 parte:
    - **Parte 1** - 
    - **Parte 2** - André Cardoso
    - **Parte 3** - 
    - **Parte 4** - 
    - **Parte 5** - 