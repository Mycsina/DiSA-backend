// Generated from Adv.g4 by ANTLR 4.12.0
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link AdvParser}.
 */
public interface AdvListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link AdvParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(AdvParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(AdvParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#structs}.
	 * @param ctx the parse tree
	 */
	void enterStructs(AdvParser.StructsContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#structs}.
	 * @param ctx the parse tree
	 */
	void exitStructs(AdvParser.StructsContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#play}.
	 * @param ctx the parse tree
	 */
	void enterPlay(AdvParser.PlayContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#play}.
	 * @param ctx the parse tree
	 */
	void exitPlay(AdvParser.PlayContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#animation}.
	 * @param ctx the parse tree
	 */
	void enterAnimation(AdvParser.AnimationContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#animation}.
	 * @param ctx the parse tree
	 */
	void exitAnimation(AdvParser.AnimationContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#decl_animation}.
	 * @param ctx the parse tree
	 */
	void enterDecl_animation(AdvParser.Decl_animationContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#decl_animation}.
	 * @param ctx the parse tree
	 */
	void exitDecl_animation(AdvParser.Decl_animationContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#animation_body}.
	 * @param ctx the parse tree
	 */
	void enterAnimation_body(AdvParser.Animation_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#animation_body}.
	 * @param ctx the parse tree
	 */
	void exitAnimation_body(AdvParser.Animation_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#viewport_description}.
	 * @param ctx the parse tree
	 */
	void enterViewport_description(AdvParser.Viewport_descriptionContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#viewport_description}.
	 * @param ctx the parse tree
	 */
	void exitViewport_description(AdvParser.Viewport_descriptionContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#viewport_commands}.
	 * @param ctx the parse tree
	 */
	void enterViewport_commands(AdvParser.Viewport_commandsContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#viewport_commands}.
	 * @param ctx the parse tree
	 */
	void exitViewport_commands(AdvParser.Viewport_commandsContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#pause}.
	 * @param ctx the parse tree
	 */
	void enterPause(AdvParser.PauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#pause}.
	 * @param ctx the parse tree
	 */
	void exitPause(AdvParser.PauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#show_command}.
	 * @param ctx the parse tree
	 */
	void enterShow_command(AdvParser.Show_commandContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#show_command}.
	 * @param ctx the parse tree
	 */
	void exitShow_command(AdvParser.Show_commandContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#showables}.
	 * @param ctx the parse tree
	 */
	void enterShowables(AdvParser.ShowablesContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#showables}.
	 * @param ctx the parse tree
	 */
	void exitShowables(AdvParser.ShowablesContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#viewport}.
	 * @param ctx the parse tree
	 */
	void enterViewport(AdvParser.ViewportContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#viewport}.
	 * @param ctx the parse tree
	 */
	void exitViewport(AdvParser.ViewportContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#view}.
	 * @param ctx the parse tree
	 */
	void enterView(AdvParser.ViewContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#view}.
	 * @param ctx the parse tree
	 */
	void exitView(AdvParser.ViewContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#view_body}.
	 * @param ctx the parse tree
	 */
	void enterView_body(AdvParser.View_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#view_body}.
	 * @param ctx the parse tree
	 */
	void exitView_body(AdvParser.View_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#grid_statement}.
	 * @param ctx the parse tree
	 */
	void enterGrid_statement(AdvParser.Grid_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#grid_statement}.
	 * @param ctx the parse tree
	 */
	void exitGrid_statement(AdvParser.Grid_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#transition_arrow_statement}.
	 * @param ctx the parse tree
	 */
	void enterTransition_arrow_statement(AdvParser.Transition_arrow_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#transition_arrow_statement}.
	 * @param ctx the parse tree
	 */
	void exitTransition_arrow_statement(AdvParser.Transition_arrow_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#multi_point_declaration}.
	 * @param ctx the parse tree
	 */
	void enterMulti_point_declaration(AdvParser.Multi_point_declarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#multi_point_declaration}.
	 * @param ctx the parse tree
	 */
	void exitMulti_point_declaration(AdvParser.Multi_point_declarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#point_decl_assign}.
	 * @param ctx the parse tree
	 */
	void enterPoint_decl_assign(AdvParser.Point_decl_assignContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#point_decl_assign}.
	 * @param ctx the parse tree
	 */
	void exitPoint_decl_assign(AdvParser.Point_decl_assignContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#point_assignment}.
	 * @param ctx the parse tree
	 */
	void enterPoint_assignment(AdvParser.Point_assignmentContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#point_assignment}.
	 * @param ctx the parse tree
	 */
	void exitPoint_assignment(AdvParser.Point_assignmentContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#point}.
	 * @param ctx the parse tree
	 */
	void enterPoint(AdvParser.PointContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#point}.
	 * @param ctx the parse tree
	 */
	void exitPoint(AdvParser.PointContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#place_statement}.
	 * @param ctx the parse tree
	 */
	void enterPlace_statement(AdvParser.Place_statementContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#place_statement}.
	 * @param ctx the parse tree
	 */
	void exitPlace_statement(AdvParser.Place_statementContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#place_in}.
	 * @param ctx the parse tree
	 */
	void enterPlace_in(AdvParser.Place_inContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#place_in}.
	 * @param ctx the parse tree
	 */
	void exitPlace_in(AdvParser.Place_inContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#placeable}.
	 * @param ctx the parse tree
	 */
	void enterPlaceable(AdvParser.PlaceableContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#placeable}.
	 * @param ctx the parse tree
	 */
	void exitPlaceable(AdvParser.PlaceableContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#keypair_properties}.
	 * @param ctx the parse tree
	 */
	void enterKeypair_properties(AdvParser.Keypair_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#keypair_properties}.
	 * @param ctx the parse tree
	 */
	void exitKeypair_properties(AdvParser.Keypair_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#key_values}.
	 * @param ctx the parse tree
	 */
	void enterKey_values(AdvParser.Key_valuesContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#key_values}.
	 * @param ctx the parse tree
	 */
	void exitKey_values(AdvParser.Key_valuesContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#key_value}.
	 * @param ctx the parse tree
	 */
	void enterKey_value(AdvParser.Key_valueContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#key_value}.
	 * @param ctx the parse tree
	 */
	void exitKey_value(AdvParser.Key_valueContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#view_transition}.
	 * @param ctx the parse tree
	 */
	void enterView_transition(AdvParser.View_transitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#view_transition}.
	 * @param ctx the parse tree
	 */
	void exitView_transition(AdvParser.View_transitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#decl_view}.
	 * @param ctx the parse tree
	 */
	void enterDecl_view(AdvParser.Decl_viewContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#decl_view}.
	 * @param ctx the parse tree
	 */
	void exitDecl_view(AdvParser.Decl_viewContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#automaton}.
	 * @param ctx the parse tree
	 */
	void enterAutomaton(AdvParser.AutomatonContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#automaton}.
	 * @param ctx the parse tree
	 */
	void exitAutomaton(AdvParser.AutomatonContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#automaton_body}.
	 * @param ctx the parse tree
	 */
	void enterAutomaton_body(AdvParser.Automaton_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#automaton_body}.
	 * @param ctx the parse tree
	 */
	void exitAutomaton_body(AdvParser.Automaton_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#for_loop_viewport}.
	 * @param ctx the parse tree
	 */
	void enterFor_loop_viewport(AdvParser.For_loop_viewportContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#for_loop_viewport}.
	 * @param ctx the parse tree
	 */
	void exitFor_loop_viewport(AdvParser.For_loop_viewportContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#automaton_commands}.
	 * @param ctx the parse tree
	 */
	void enterAutomaton_commands(AdvParser.Automaton_commandsContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#automaton_commands}.
	 * @param ctx the parse tree
	 */
	void exitAutomaton_commands(AdvParser.Automaton_commandsContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#for_loop_state}.
	 * @param ctx the parse tree
	 */
	void enterFor_loop_state(AdvParser.For_loop_stateContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#for_loop_state}.
	 * @param ctx the parse tree
	 */
	void exitFor_loop_state(AdvParser.For_loop_stateContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#list}.
	 * @param ctx the parse tree
	 */
	void enterList(AdvParser.ListContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#list}.
	 * @param ctx the parse tree
	 */
	void exitList(AdvParser.ListContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#state_transitions}.
	 * @param ctx the parse tree
	 */
	void enterState_transitions(AdvParser.State_transitionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#state_transitions}.
	 * @param ctx the parse tree
	 */
	void exitState_transitions(AdvParser.State_transitionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#automaton_transition}.
	 * @param ctx the parse tree
	 */
	void enterAutomaton_transition(AdvParser.Automaton_transitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#automaton_transition}.
	 * @param ctx the parse tree
	 */
	void exitAutomaton_transition(AdvParser.Automaton_transitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#change_state_property}.
	 * @param ctx the parse tree
	 */
	void enterChange_state_property(AdvParser.Change_state_propertyContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#change_state_property}.
	 * @param ctx the parse tree
	 */
	void exitChange_state_property(AdvParser.Change_state_propertyContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#declare_states}.
	 * @param ctx the parse tree
	 */
	void enterDeclare_states(AdvParser.Declare_statesContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#declare_states}.
	 * @param ctx the parse tree
	 */
	void exitDeclare_states(AdvParser.Declare_statesContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#decl_automaton}.
	 * @param ctx the parse tree
	 */
	void enterDecl_automaton(AdvParser.Decl_automatonContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#decl_automaton}.
	 * @param ctx the parse tree
	 */
	void exitDecl_automaton(AdvParser.Decl_automatonContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#alphabet}.
	 * @param ctx the parse tree
	 */
	void enterAlphabet(AdvParser.AlphabetContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#alphabet}.
	 * @param ctx the parse tree
	 */
	void exitAlphabet(AdvParser.AlphabetContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#transition}.
	 * @param ctx the parse tree
	 */
	void enterTransition(AdvParser.TransitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#transition}.
	 * @param ctx the parse tree
	 */
	void exitTransition(AdvParser.TransitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#vector}.
	 * @param ctx the parse tree
	 */
	void enterVector(AdvParser.VectorContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#vector}.
	 * @param ctx the parse tree
	 */
	void exitVector(AdvParser.VectorContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#cart_vector}.
	 * @param ctx the parse tree
	 */
	void enterCart_vector(AdvParser.Cart_vectorContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#cart_vector}.
	 * @param ctx the parse tree
	 */
	void exitCart_vector(AdvParser.Cart_vectorContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#polar_vector}.
	 * @param ctx the parse tree
	 */
	void enterPolar_vector(AdvParser.Polar_vectorContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#polar_vector}.
	 * @param ctx the parse tree
	 */
	void exitPolar_vector(AdvParser.Polar_vectorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprAddSub}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprAddSub(AdvParser.ExprAddSubContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprAddSub}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprAddSub(AdvParser.ExprAddSubContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprParenthesis}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprParenthesis(AdvParser.ExprParenthesisContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprParenthesis}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprParenthesis(AdvParser.ExprParenthesisContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprNumber}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprNumber(AdvParser.ExprNumberContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprNumber}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprNumber(AdvParser.ExprNumberContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprName}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprName(AdvParser.ExprNameContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprName}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprName(AdvParser.ExprNameContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprPositiveNegative}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprPositiveNegative(AdvParser.ExprPositiveNegativeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprPositiveNegative}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprPositiveNegative(AdvParser.ExprPositiveNegativeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprMulDiv}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprMulDiv(AdvParser.ExprMulDivContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprMulDiv}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprMulDiv(AdvParser.ExprMulDivContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprVector}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprVector(AdvParser.ExprVectorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprVector}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprVector(AdvParser.ExprVectorContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#keypair_value}.
	 * @param ctx the parse tree
	 */
	void enterKeypair_value(AdvParser.Keypair_valueContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#keypair_value}.
	 * @param ctx the parse tree
	 */
	void exitKeypair_value(AdvParser.Keypair_valueContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#number}.
	 * @param ctx the parse tree
	 */
	void enterNumber(AdvParser.NumberContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#number}.
	 * @param ctx the parse tree
	 */
	void exitNumber(AdvParser.NumberContext ctx);
	/**
	 * Enter a parse tree produced by {@link AdvParser#automaton_types}.
	 * @param ctx the parse tree
	 */
	void enterAutomaton_types(AdvParser.Automaton_typesContext ctx);
	/**
	 * Exit a parse tree produced by {@link AdvParser#automaton_types}.
	 * @param ctx the parse tree
	 */
	void exitAutomaton_types(AdvParser.Automaton_typesContext ctx);
}