// Generated from Adv.g4 by ANTLR 4.12.0
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link AdvParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface AdvVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link AdvParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(AdvParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#structs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStructs(AdvParser.StructsContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#play}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlay(AdvParser.PlayContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#animation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnimation(AdvParser.AnimationContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#decl_animation}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecl_animation(AdvParser.Decl_animationContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#animation_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnimation_body(AdvParser.Animation_bodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#viewport_description}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitViewport_description(AdvParser.Viewport_descriptionContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#viewport_commands}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitViewport_commands(AdvParser.Viewport_commandsContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#pause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPause(AdvParser.PauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#show_command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShow_command(AdvParser.Show_commandContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#showables}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShowables(AdvParser.ShowablesContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#viewport}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitViewport(AdvParser.ViewportContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#view}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitView(AdvParser.ViewContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#view_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitView_body(AdvParser.View_bodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#grid_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGrid_statement(AdvParser.Grid_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#transition_arrow_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTransition_arrow_statement(AdvParser.Transition_arrow_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#multi_point_declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulti_point_declaration(AdvParser.Multi_point_declarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#point_decl_assign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPoint_decl_assign(AdvParser.Point_decl_assignContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#point_assignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPoint_assignment(AdvParser.Point_assignmentContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#point}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPoint(AdvParser.PointContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#place_statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlace_statement(AdvParser.Place_statementContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#place_in}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlace_in(AdvParser.Place_inContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#placeable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlaceable(AdvParser.PlaceableContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#keypair_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeypair_properties(AdvParser.Keypair_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#key_values}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKey_values(AdvParser.Key_valuesContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#key_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKey_value(AdvParser.Key_valueContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#view_transition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitView_transition(AdvParser.View_transitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#decl_view}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecl_view(AdvParser.Decl_viewContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#automaton}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAutomaton(AdvParser.AutomatonContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#automaton_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAutomaton_body(AdvParser.Automaton_bodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#for_loop_viewport}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_loop_viewport(AdvParser.For_loop_viewportContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#automaton_commands}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAutomaton_commands(AdvParser.Automaton_commandsContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#for_loop_state}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_loop_state(AdvParser.For_loop_stateContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList(AdvParser.ListContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#state_transitions}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitState_transitions(AdvParser.State_transitionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#automaton_transition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAutomaton_transition(AdvParser.Automaton_transitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#change_state_property}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChange_state_property(AdvParser.Change_state_propertyContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#declare_states}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclare_states(AdvParser.Declare_statesContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#decl_automaton}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecl_automaton(AdvParser.Decl_automatonContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#alphabet}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlphabet(AdvParser.AlphabetContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#transition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTransition(AdvParser.TransitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#vector}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVector(AdvParser.VectorContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#cart_vector}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCart_vector(AdvParser.Cart_vectorContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#polar_vector}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPolar_vector(AdvParser.Polar_vectorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprAddSub}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprAddSub(AdvParser.ExprAddSubContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprParenthesis}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprParenthesis(AdvParser.ExprParenthesisContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprNumber}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprNumber(AdvParser.ExprNumberContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprName}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprName(AdvParser.ExprNameContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprPositiveNegative}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprPositiveNegative(AdvParser.ExprPositiveNegativeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprMulDiv}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprMulDiv(AdvParser.ExprMulDivContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprVector}
	 * labeled alternative in {@link AdvParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprVector(AdvParser.ExprVectorContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#keypair_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeypair_value(AdvParser.Keypair_valueContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#number}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumber(AdvParser.NumberContext ctx);
	/**
	 * Visit a parse tree produced by {@link AdvParser#automaton_types}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAutomaton_types(AdvParser.Automaton_typesContext ctx);
}