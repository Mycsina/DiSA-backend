// Generated from Adv.g4 by ANTLR 4.12.0
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class AdvParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.12.0", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, T__21=22, T__22=23, T__23=24, 
		T__24=25, T__25=26, T__26=27, T__27=28, T__28=29, T__29=30, T__30=31, 
		T__31=32, T__32=33, T__33=34, T__34=35, T__35=36, T__36=37, T__37=38, 
		T__38=39, T__39=40, T__40=41, T__41=42, T__42=43, T__43=44, T__44=45, 
		T__45=46, T__46=47, T__47=48, STR=49, INT=50, REAL=51, LINE_COMMENT=52, 
		COMMENT=53, NAME=54, SYMBOL=55, WS=56;
	public static final int
		RULE_program = 0, RULE_structs = 1, RULE_play = 2, RULE_animation = 3, 
		RULE_decl_animation = 4, RULE_animation_body = 5, RULE_viewport_description = 6, 
		RULE_viewport_commands = 7, RULE_pause = 8, RULE_show_command = 9, RULE_showables = 10, 
		RULE_viewport = 11, RULE_view = 12, RULE_view_body = 13, RULE_grid_statement = 14, 
		RULE_transition_arrow_statement = 15, RULE_multi_point_declaration = 16, 
		RULE_point_decl_assign = 17, RULE_point_assignment = 18, RULE_point = 19, 
		RULE_place_statement = 20, RULE_place_in = 21, RULE_placeable = 22, RULE_keypair_properties = 23, 
		RULE_key_values = 24, RULE_key_value = 25, RULE_view_transition = 26, 
		RULE_decl_view = 27, RULE_automaton = 28, RULE_automaton_body = 29, RULE_for_loop_viewport = 30, 
		RULE_automaton_commands = 31, RULE_for_loop_state = 32, RULE_list = 33, 
		RULE_state_transitions = 34, RULE_automaton_transition = 35, RULE_change_state_property = 36, 
		RULE_declare_states = 37, RULE_decl_automaton = 38, RULE_alphabet = 39, 
		RULE_transition = 40, RULE_vector = 41, RULE_cart_vector = 42, RULE_polar_vector = 43, 
		RULE_expr = 44, RULE_keypair_value = 45, RULE_number = 46, RULE_automaton_types = 47;
	private static String[] makeRuleNames() {
		return new String[] {
			"program", "structs", "play", "animation", "decl_animation", "animation_body", 
			"viewport_description", "viewport_commands", "pause", "show_command", 
			"showables", "viewport", "view", "view_body", "grid_statement", "transition_arrow_statement", 
			"multi_point_declaration", "point_decl_assign", "point_assignment", "point", 
			"place_statement", "place_in", "placeable", "keypair_properties", "key_values", 
			"key_value", "view_transition", "decl_view", "automaton", "automaton_body", 
			"for_loop_viewport", "automaton_commands", "for_loop_state", "list", 
			"state_transitions", "automaton_transition", "change_state_property", 
			"declare_states", "decl_automaton", "alphabet", "transition", "vector", 
			"cart_vector", "polar_vector", "expr", "keypair_value", "number", "automaton_types"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'play'", "'<<<'", "'>>>'", "'animation'", "'on'", "'pause'", "';'", 
			"'show'", "','", "'['", "'initial'", "'accepting'", "'='", "'true'", 
			"'false'", "']'", "'viewport'", "'for'", "'at'", "'--'", "'++'", "'grid'", 
			"'('", "')'", "'as'", "'..'", "'point'", "'place'", "'#label'", "'view'", 
			"'of'", "'in'", "'{'", "'}'", "'transition'", "'->'", "'state'", "'alphabet'", 
			"'<'", "'>'", "':'", "'*'", "'/'", "'+'", "'-'", "'NFA'", "'complete'", 
			"'DFA'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, "STR", "INT", "REAL", "LINE_COMMENT", "COMMENT", "NAME", "SYMBOL", 
			"WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Adv.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public AdvParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgramContext extends ParserRuleContext {
		public AlphabetContext alphabet() {
			return getRuleContext(AlphabetContext.class,0);
		}
		public List<StructsContext> structs() {
			return getRuleContexts(StructsContext.class);
		}
		public StructsContext structs(int i) {
			return getRuleContext(StructsContext.class,i);
		}
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitProgram(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitProgram(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(96);
			alphabet();
			setState(98); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(97);
				structs();
				}
				}
				setState(100); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 492581209243648L) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StructsContext extends ParserRuleContext {
		public List<AutomatonContext> automaton() {
			return getRuleContexts(AutomatonContext.class);
		}
		public AutomatonContext automaton(int i) {
			return getRuleContext(AutomatonContext.class,i);
		}
		public List<ViewContext> view() {
			return getRuleContexts(ViewContext.class);
		}
		public ViewContext view(int i) {
			return getRuleContext(ViewContext.class,i);
		}
		public List<AnimationContext> animation() {
			return getRuleContexts(AnimationContext.class);
		}
		public AnimationContext animation(int i) {
			return getRuleContext(AnimationContext.class,i);
		}
		public List<PlayContext> play() {
			return getRuleContexts(PlayContext.class);
		}
		public PlayContext play(int i) {
			return getRuleContext(PlayContext.class,i);
		}
		public StructsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_structs; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterStructs(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitStructs(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitStructs(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StructsContext structs() throws RecognitionException {
		StructsContext _localctx = new StructsContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_structs);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(103); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(102);
				automaton();
				}
				}
				setState(105); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 492581209243648L) != 0) );
			setState(108); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(107);
				view();
				}
				}
				setState(110); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__29 );
			setState(113); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(112);
				animation();
				}
				}
				setState(115); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__3 );
			setState(118); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(117);
				play();
				}
				}
				setState(120); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__0 );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PlayContext extends ParserRuleContext {
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public PlayContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_play; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterPlay(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitPlay(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitPlay(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PlayContext play() throws RecognitionException {
		PlayContext _localctx = new PlayContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_play);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(122);
			match(T__0);
			setState(123);
			match(NAME);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AnimationContext extends ParserRuleContext {
		public Decl_animationContext decl_animation() {
			return getRuleContext(Decl_animationContext.class,0);
		}
		public Animation_bodyContext animation_body() {
			return getRuleContext(Animation_bodyContext.class,0);
		}
		public AnimationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_animation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterAnimation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitAnimation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitAnimation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AnimationContext animation() throws RecognitionException {
		AnimationContext _localctx = new AnimationContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_animation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(125);
			decl_animation();
			setState(126);
			match(T__1);
			setState(127);
			animation_body();
			setState(128);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Decl_animationContext extends ParserRuleContext {
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public Decl_animationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decl_animation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterDecl_animation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitDecl_animation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitDecl_animation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Decl_animationContext decl_animation() throws RecognitionException {
		Decl_animationContext _localctx = new Decl_animationContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_decl_animation);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(130);
			match(T__3);
			setState(131);
			match(NAME);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Animation_bodyContext extends ParserRuleContext {
		public List<ViewportContext> viewport() {
			return getRuleContexts(ViewportContext.class);
		}
		public ViewportContext viewport(int i) {
			return getRuleContext(ViewportContext.class,i);
		}
		public List<Viewport_descriptionContext> viewport_description() {
			return getRuleContexts(Viewport_descriptionContext.class);
		}
		public Viewport_descriptionContext viewport_description(int i) {
			return getRuleContext(Viewport_descriptionContext.class,i);
		}
		public Animation_bodyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_animation_body; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterAnimation_body(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitAnimation_body(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitAnimation_body(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Animation_bodyContext animation_body() throws RecognitionException {
		Animation_bodyContext _localctx = new Animation_bodyContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_animation_body);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(134); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(133);
				viewport();
				}
				}
				setState(136); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__16 );
			setState(139); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(138);
				viewport_description();
				}
				}
				setState(141); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__4 );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Viewport_descriptionContext extends ParserRuleContext {
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public List<Viewport_commandsContext> viewport_commands() {
			return getRuleContexts(Viewport_commandsContext.class);
		}
		public Viewport_commandsContext viewport_commands(int i) {
			return getRuleContext(Viewport_commandsContext.class,i);
		}
		public Viewport_descriptionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_viewport_description; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterViewport_description(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitViewport_description(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitViewport_description(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Viewport_descriptionContext viewport_description() throws RecognitionException {
		Viewport_descriptionContext _localctx = new Viewport_descriptionContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_viewport_description);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(143);
			match(T__4);
			setState(144);
			match(NAME);
			setState(145);
			match(T__1);
			setState(147); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(146);
				viewport_commands();
				}
				}
				setState(149); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 262464L) != 0) );
			setState(151);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Viewport_commandsContext extends ParserRuleContext {
		public Show_commandContext show_command() {
			return getRuleContext(Show_commandContext.class,0);
		}
		public PauseContext pause() {
			return getRuleContext(PauseContext.class,0);
		}
		public For_loop_viewportContext for_loop_viewport() {
			return getRuleContext(For_loop_viewportContext.class,0);
		}
		public Viewport_commandsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_viewport_commands; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterViewport_commands(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitViewport_commands(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitViewport_commands(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Viewport_commandsContext viewport_commands() throws RecognitionException {
		Viewport_commandsContext _localctx = new Viewport_commandsContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_viewport_commands);
		try {
			setState(156);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__7:
				enterOuterAlt(_localctx, 1);
				{
				setState(153);
				show_command();
				}
				break;
			case T__5:
				enterOuterAlt(_localctx, 2);
				{
				setState(154);
				pause();
				}
				break;
			case T__17:
				enterOuterAlt(_localctx, 3);
				{
				setState(155);
				for_loop_viewport();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PauseContext extends ParserRuleContext {
		public PauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterPause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitPause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitPause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PauseContext pause() throws RecognitionException {
		PauseContext _localctx = new PauseContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_pause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(158);
			match(T__5);
			setState(159);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Show_commandContext extends ParserRuleContext {
		public List<ShowablesContext> showables() {
			return getRuleContexts(ShowablesContext.class);
		}
		public ShowablesContext showables(int i) {
			return getRuleContext(ShowablesContext.class,i);
		}
		public Show_commandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_show_command; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterShow_command(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitShow_command(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitShow_command(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Show_commandContext show_command() throws RecognitionException {
		Show_commandContext _localctx = new Show_commandContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_show_command);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(161);
			match(T__7);
			setState(162);
			showables();
			setState(167);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__8) {
				{
				{
				setState(163);
				match(T__8);
				setState(164);
				showables();
				}
				}
				setState(169);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(170);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ShowablesContext extends ParserRuleContext {
		public Token key;
		public Token value;
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public TransitionContext transition() {
			return getRuleContext(TransitionContext.class,0);
		}
		public ShowablesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_showables; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterShowables(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitShowables(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitShowables(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ShowablesContext showables() throws RecognitionException {
		ShowablesContext _localctx = new ShowablesContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_showables);
		int _la;
		try {
			setState(181);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NAME:
				enterOuterAlt(_localctx, 1);
				{
				{
				setState(172);
				match(NAME);
				setState(178);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__9) {
					{
					setState(173);
					match(T__9);
					setState(174);
					((ShowablesContext)_localctx).key = _input.LT(1);
					_la = _input.LA(1);
					if ( !(_la==T__10 || _la==T__11) ) {
						((ShowablesContext)_localctx).key = (Token)_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(175);
					match(T__12);
					setState(176);
					((ShowablesContext)_localctx).value = _input.LT(1);
					_la = _input.LA(1);
					if ( !(_la==T__13 || _la==T__14) ) {
						((ShowablesContext)_localctx).value = (Token)_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(177);
					match(T__15);
					}
				}

				}
				}
				break;
			case T__38:
				enterOuterAlt(_localctx, 2);
				{
				setState(180);
				transition();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ViewportContext extends ParserRuleContext {
		public Token vpname;
		public Token viewname;
		public List<Cart_vectorContext> cart_vector() {
			return getRuleContexts(Cart_vectorContext.class);
		}
		public Cart_vectorContext cart_vector(int i) {
			return getRuleContext(Cart_vectorContext.class,i);
		}
		public List<TerminalNode> NAME() { return getTokens(AdvParser.NAME); }
		public TerminalNode NAME(int i) {
			return getToken(AdvParser.NAME, i);
		}
		public ViewportContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_viewport; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterViewport(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitViewport(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitViewport(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ViewportContext viewport() throws RecognitionException {
		ViewportContext _localctx = new ViewportContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_viewport);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(183);
			match(T__16);
			setState(184);
			((ViewportContext)_localctx).vpname = match(NAME);
			setState(185);
			match(T__17);
			setState(186);
			((ViewportContext)_localctx).viewname = match(NAME);
			setState(187);
			match(T__18);
			setState(188);
			cart_vector();
			setState(189);
			match(T__19);
			setState(190);
			match(T__20);
			setState(191);
			cart_vector();
			setState(192);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ViewContext extends ParserRuleContext {
		public Decl_viewContext decl_view() {
			return getRuleContext(Decl_viewContext.class,0);
		}
		public View_bodyContext view_body() {
			return getRuleContext(View_bodyContext.class,0);
		}
		public ViewContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_view; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterView(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitView(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitView(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ViewContext view() throws RecognitionException {
		ViewContext _localctx = new ViewContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_view);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(194);
			decl_view();
			setState(195);
			match(T__1);
			setState(196);
			view_body();
			setState(197);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class View_bodyContext extends ParserRuleContext {
		public List<Place_statementContext> place_statement() {
			return getRuleContexts(Place_statementContext.class);
		}
		public Place_statementContext place_statement(int i) {
			return getRuleContext(Place_statementContext.class,i);
		}
		public List<Multi_point_declarationContext> multi_point_declaration() {
			return getRuleContexts(Multi_point_declarationContext.class);
		}
		public Multi_point_declarationContext multi_point_declaration(int i) {
			return getRuleContext(Multi_point_declarationContext.class,i);
		}
		public List<Point_decl_assignContext> point_decl_assign() {
			return getRuleContexts(Point_decl_assignContext.class);
		}
		public Point_decl_assignContext point_decl_assign(int i) {
			return getRuleContext(Point_decl_assignContext.class,i);
		}
		public List<Point_assignmentContext> point_assignment() {
			return getRuleContexts(Point_assignmentContext.class);
		}
		public Point_assignmentContext point_assignment(int i) {
			return getRuleContext(Point_assignmentContext.class,i);
		}
		public List<Transition_arrow_statementContext> transition_arrow_statement() {
			return getRuleContexts(Transition_arrow_statementContext.class);
		}
		public Transition_arrow_statementContext transition_arrow_statement(int i) {
			return getRuleContext(Transition_arrow_statementContext.class,i);
		}
		public List<Grid_statementContext> grid_statement() {
			return getRuleContexts(Grid_statementContext.class);
		}
		public Grid_statementContext grid_statement(int i) {
			return getRuleContext(Grid_statementContext.class,i);
		}
		public List<View_transitionContext> view_transition() {
			return getRuleContexts(View_transitionContext.class);
		}
		public View_transitionContext view_transition(int i) {
			return getRuleContext(View_transitionContext.class,i);
		}
		public View_bodyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_view_body; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterView_body(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitView_body(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitView_body(this);
			else return visitor.visitChildren(this);
		}
	}

	public final View_bodyContext view_body() throws RecognitionException {
		View_bodyContext _localctx = new View_bodyContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_view_body);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(220); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				setState(220);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
				case 1:
					{
					setState(199);
					place_statement();
					setState(200);
					match(T__6);
					}
					break;
				case 2:
					{
					setState(202);
					multi_point_declaration();
					setState(203);
					match(T__6);
					}
					break;
				case 3:
					{
					setState(205);
					point_decl_assign();
					setState(206);
					match(T__6);
					}
					break;
				case 4:
					{
					setState(208);
					point_assignment();
					setState(209);
					match(T__6);
					}
					break;
				case 5:
					{
					setState(211);
					transition_arrow_statement();
					setState(212);
					match(T__6);
					}
					break;
				case 6:
					{
					setState(214);
					grid_statement();
					setState(215);
					match(T__6);
					}
					break;
				case 7:
					{
					setState(217);
					view_transition();
					setState(218);
					match(T__6);
					}
					break;
				}
				}
				setState(222); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 18014948672143360L) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Grid_statementContext extends ParserRuleContext {
		public Token width;
		public Token height;
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public Keypair_propertiesContext keypair_properties() {
			return getRuleContext(Keypair_propertiesContext.class,0);
		}
		public List<TerminalNode> INT() { return getTokens(AdvParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(AdvParser.INT, i);
		}
		public Grid_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_grid_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterGrid_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitGrid_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitGrid_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Grid_statementContext grid_statement() throws RecognitionException {
		Grid_statementContext _localctx = new Grid_statementContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_grid_statement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(224);
			match(T__21);
			setState(225);
			match(NAME);
			setState(226);
			match(T__22);
			setState(227);
			((Grid_statementContext)_localctx).width = match(INT);
			setState(228);
			match(T__8);
			setState(229);
			((Grid_statementContext)_localctx).height = match(INT);
			setState(230);
			match(T__23);
			setState(231);
			keypair_properties();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Transition_arrow_statementContext extends ParserRuleContext {
		public Token arrow_type;
		public TransitionContext transition() {
			return getRuleContext(TransitionContext.class,0);
		}
		public List<PointContext> point() {
			return getRuleContexts(PointContext.class);
		}
		public PointContext point(int i) {
			return getRuleContext(PointContext.class,i);
		}
		public Transition_arrow_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_transition_arrow_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterTransition_arrow_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitTransition_arrow_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitTransition_arrow_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Transition_arrow_statementContext transition_arrow_statement() throws RecognitionException {
		Transition_arrow_statementContext _localctx = new Transition_arrow_statementContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_transition_arrow_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(233);
			transition();
			setState(234);
			match(T__24);
			setState(235);
			point();
			setState(236);
			((Transition_arrow_statementContext)_localctx).arrow_type = _input.LT(1);
			_la = _input.LA(1);
			if ( !(_la==T__19 || _la==T__25) ) {
				((Transition_arrow_statementContext)_localctx).arrow_type = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(237);
			point();
			setState(242);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__19 || _la==T__25) {
				{
				{
				setState(238);
				((Transition_arrow_statementContext)_localctx).arrow_type = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==T__19 || _la==T__25) ) {
					((Transition_arrow_statementContext)_localctx).arrow_type = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(239);
				point();
				}
				}
				setState(244);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Multi_point_declarationContext extends ParserRuleContext {
		public List<TerminalNode> NAME() { return getTokens(AdvParser.NAME); }
		public TerminalNode NAME(int i) {
			return getToken(AdvParser.NAME, i);
		}
		public Multi_point_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multi_point_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterMulti_point_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitMulti_point_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitMulti_point_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Multi_point_declarationContext multi_point_declaration() throws RecognitionException {
		Multi_point_declarationContext _localctx = new Multi_point_declarationContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_multi_point_declaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(245);
			match(T__26);
			setState(246);
			match(NAME);
			setState(251);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__8) {
				{
				{
				setState(247);
				match(T__8);
				setState(248);
				match(NAME);
				}
				}
				setState(253);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Point_decl_assignContext extends ParserRuleContext {
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public PointContext point() {
			return getRuleContext(PointContext.class,0);
		}
		public Point_decl_assignContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_point_decl_assign; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterPoint_decl_assign(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitPoint_decl_assign(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitPoint_decl_assign(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Point_decl_assignContext point_decl_assign() throws RecognitionException {
		Point_decl_assignContext _localctx = new Point_decl_assignContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_point_decl_assign);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(254);
			match(T__26);
			setState(255);
			match(NAME);
			setState(256);
			match(T__12);
			setState(257);
			point();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Point_assignmentContext extends ParserRuleContext {
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public PointContext point() {
			return getRuleContext(PointContext.class,0);
		}
		public Point_assignmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_point_assignment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterPoint_assignment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitPoint_assignment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitPoint_assignment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Point_assignmentContext point_assignment() throws RecognitionException {
		Point_assignmentContext _localctx = new Point_assignmentContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_point_assignment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(259);
			match(NAME);
			setState(260);
			match(T__12);
			setState(261);
			point();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PointContext extends ParserRuleContext {
		public Token state;
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public VectorContext vector() {
			return getRuleContext(VectorContext.class,0);
		}
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public PointContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_point; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterPoint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitPoint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitPoint(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PointContext point() throws RecognitionException {
		PointContext _localctx = new PointContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_point);
		try {
			setState(268);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				{
				setState(263);
				match(T__22);
				setState(264);
				((PointContext)_localctx).state = match(NAME);
				setState(265);
				match(T__23);
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(266);
				vector();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(267);
				expr(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Place_statementContext extends ParserRuleContext {
		public List<PlaceableContext> placeable() {
			return getRuleContexts(PlaceableContext.class);
		}
		public PlaceableContext placeable(int i) {
			return getRuleContext(PlaceableContext.class,i);
		}
		public List<Place_inContext> place_in() {
			return getRuleContexts(Place_inContext.class);
		}
		public Place_inContext place_in(int i) {
			return getRuleContext(Place_inContext.class,i);
		}
		public Place_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_place_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterPlace_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitPlace_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitPlace_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Place_statementContext place_statement() throws RecognitionException {
		Place_statementContext _localctx = new Place_statementContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_place_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(270);
			match(T__27);
			setState(271);
			placeable();
			setState(272);
			match(T__18);
			setState(273);
			place_in();
			setState(281);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__8) {
				{
				{
				setState(274);
				match(T__8);
				setState(275);
				placeable();
				setState(276);
				match(T__18);
				setState(277);
				place_in();
				}
				}
				setState(283);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Place_inContext extends ParserRuleContext {
		public VectorContext vector() {
			return getRuleContext(VectorContext.class,0);
		}
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public Place_inContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_place_in; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterPlace_in(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitPlace_in(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitPlace_in(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Place_inContext place_in() throws RecognitionException {
		Place_inContext _localctx = new Place_inContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_place_in);
		try {
			setState(286);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__22:
				enterOuterAlt(_localctx, 1);
				{
				setState(284);
				vector();
				}
				break;
			case NAME:
				enterOuterAlt(_localctx, 2);
				{
				setState(285);
				match(NAME);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PlaceableContext extends ParserRuleContext {
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public View_transitionContext view_transition() {
			return getRuleContext(View_transitionContext.class,0);
		}
		public PlaceableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_placeable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterPlaceable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitPlaceable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitPlaceable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PlaceableContext placeable() throws RecognitionException {
		PlaceableContext _localctx = new PlaceableContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_placeable);
		try {
			setState(290);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NAME:
				enterOuterAlt(_localctx, 1);
				{
				setState(288);
				match(NAME);
				}
				break;
			case T__38:
				enterOuterAlt(_localctx, 2);
				{
				setState(289);
				view_transition();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Keypair_propertiesContext extends ParserRuleContext {
		public Key_valuesContext key_values() {
			return getRuleContext(Key_valuesContext.class,0);
		}
		public Keypair_propertiesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_keypair_properties; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterKeypair_properties(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitKeypair_properties(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitKeypair_properties(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Keypair_propertiesContext keypair_properties() throws RecognitionException {
		Keypair_propertiesContext _localctx = new Keypair_propertiesContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_keypair_properties);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(292);
			match(T__9);
			setState(293);
			key_values();
			setState(294);
			match(T__15);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Key_valuesContext extends ParserRuleContext {
		public List<Key_valueContext> key_value() {
			return getRuleContexts(Key_valueContext.class);
		}
		public Key_valueContext key_value(int i) {
			return getRuleContext(Key_valueContext.class,i);
		}
		public Key_valuesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_key_values; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterKey_values(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitKey_values(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitKey_values(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Key_valuesContext key_values() throws RecognitionException {
		Key_valuesContext _localctx = new Key_valuesContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_key_values);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(296);
			key_value();
			setState(301);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__8) {
				{
				{
				setState(297);
				match(T__8);
				setState(298);
				key_value();
				}
				}
				setState(303);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Key_valueContext extends ParserRuleContext {
		public Token key;
		public Keypair_valueContext value;
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public List<Keypair_valueContext> keypair_value() {
			return getRuleContexts(Keypair_valueContext.class);
		}
		public Keypair_valueContext keypair_value(int i) {
			return getRuleContext(Keypair_valueContext.class,i);
		}
		public Key_valueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_key_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterKey_value(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitKey_value(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitKey_value(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Key_valueContext key_value() throws RecognitionException {
		Key_valueContext _localctx = new Key_valueContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_key_value);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(304);
			((Key_valueContext)_localctx).key = match(NAME);
			setState(305);
			match(T__12);
			setState(307); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(306);
				((Key_valueContext)_localctx).value = keypair_value();
				}
				}
				setState(309); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 21392098230009856L) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class View_transitionContext extends ParserRuleContext {
		public TransitionContext transition() {
			return getRuleContext(TransitionContext.class,0);
		}
		public Keypair_propertiesContext keypair_properties() {
			return getRuleContext(Keypair_propertiesContext.class,0);
		}
		public View_transitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_view_transition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterView_transition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitView_transition(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitView_transition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final View_transitionContext view_transition() throws RecognitionException {
		View_transitionContext _localctx = new View_transitionContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_view_transition);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(311);
			transition();
			setState(312);
			match(T__28);
			setState(313);
			keypair_properties();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Decl_viewContext extends ParserRuleContext {
		public Token vpname;
		public Token automname;
		public List<TerminalNode> NAME() { return getTokens(AdvParser.NAME); }
		public TerminalNode NAME(int i) {
			return getToken(AdvParser.NAME, i);
		}
		public Decl_viewContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decl_view; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterDecl_view(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitDecl_view(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitDecl_view(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Decl_viewContext decl_view() throws RecognitionException {
		Decl_viewContext _localctx = new Decl_viewContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_decl_view);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(315);
			match(T__29);
			setState(316);
			((Decl_viewContext)_localctx).vpname = match(NAME);
			setState(317);
			match(T__30);
			setState(318);
			((Decl_viewContext)_localctx).automname = match(NAME);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AutomatonContext extends ParserRuleContext {
		public Decl_automatonContext decl_automaton() {
			return getRuleContext(Decl_automatonContext.class,0);
		}
		public Automaton_bodyContext automaton_body() {
			return getRuleContext(Automaton_bodyContext.class,0);
		}
		public AutomatonContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_automaton; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterAutomaton(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitAutomaton(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitAutomaton(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AutomatonContext automaton() throws RecognitionException {
		AutomatonContext _localctx = new AutomatonContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_automaton);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(320);
			decl_automaton();
			setState(321);
			match(T__1);
			setState(322);
			automaton_body();
			setState(323);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Automaton_bodyContext extends ParserRuleContext {
		public State_transitionsContext state_transitions() {
			return getRuleContext(State_transitionsContext.class,0);
		}
		public List<Declare_statesContext> declare_states() {
			return getRuleContexts(Declare_statesContext.class);
		}
		public Declare_statesContext declare_states(int i) {
			return getRuleContext(Declare_statesContext.class,i);
		}
		public List<Change_state_propertyContext> change_state_property() {
			return getRuleContexts(Change_state_propertyContext.class);
		}
		public Change_state_propertyContext change_state_property(int i) {
			return getRuleContext(Change_state_propertyContext.class,i);
		}
		public List<For_loop_stateContext> for_loop_state() {
			return getRuleContexts(For_loop_stateContext.class);
		}
		public For_loop_stateContext for_loop_state(int i) {
			return getRuleContext(For_loop_stateContext.class,i);
		}
		public Automaton_bodyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_automaton_body; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterAutomaton_body(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitAutomaton_body(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitAutomaton_body(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Automaton_bodyContext automaton_body() throws RecognitionException {
		Automaton_bodyContext _localctx = new Automaton_bodyContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_automaton_body);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(326); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(325);
				declare_states();
				}
				}
				setState(328); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__36 );
			setState(334);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__17 || _la==NAME) {
				{
				setState(332);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case NAME:
					{
					setState(330);
					change_state_property();
					}
					break;
				case T__17:
					{
					setState(331);
					for_loop_state();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(336);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(337);
			state_transitions();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class For_loop_viewportContext extends ParserRuleContext {
		public Token elem;
		public ListContext list() {
			return getRuleContext(ListContext.class,0);
		}
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public List<Viewport_commandsContext> viewport_commands() {
			return getRuleContexts(Viewport_commandsContext.class);
		}
		public Viewport_commandsContext viewport_commands(int i) {
			return getRuleContext(Viewport_commandsContext.class,i);
		}
		public For_loop_viewportContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_for_loop_viewport; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterFor_loop_viewport(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitFor_loop_viewport(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitFor_loop_viewport(this);
			else return visitor.visitChildren(this);
		}
	}

	public final For_loop_viewportContext for_loop_viewport() throws RecognitionException {
		For_loop_viewportContext _localctx = new For_loop_viewportContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_for_loop_viewport);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(339);
			match(T__17);
			setState(340);
			((For_loop_viewportContext)_localctx).elem = match(NAME);
			setState(341);
			match(T__31);
			setState(342);
			match(T__32);
			setState(343);
			list();
			setState(344);
			match(T__33);
			setState(354);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__5:
			case T__7:
			case T__17:
				{
				setState(345);
				viewport_commands();
				}
				break;
			case T__1:
				{
				{
				setState(346);
				match(T__1);
				setState(350);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 262464L) != 0)) {
					{
					{
					setState(347);
					viewport_commands();
					}
					}
					setState(352);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(353);
				match(T__2);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Automaton_commandsContext extends ParserRuleContext {
		public Automaton_transitionContext automaton_transition() {
			return getRuleContext(Automaton_transitionContext.class,0);
		}
		public Change_state_propertyContext change_state_property() {
			return getRuleContext(Change_state_propertyContext.class,0);
		}
		public Declare_statesContext declare_states() {
			return getRuleContext(Declare_statesContext.class,0);
		}
		public Automaton_commandsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_automaton_commands; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterAutomaton_commands(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitAutomaton_commands(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitAutomaton_commands(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Automaton_commandsContext automaton_commands() throws RecognitionException {
		Automaton_commandsContext _localctx = new Automaton_commandsContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_automaton_commands);
		try {
			setState(359);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,27,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(356);
				automaton_transition();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(357);
				change_state_property();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(358);
				declare_states();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class For_loop_stateContext extends ParserRuleContext {
		public Token elem;
		public ListContext list() {
			return getRuleContext(ListContext.class,0);
		}
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public List<Automaton_commandsContext> automaton_commands() {
			return getRuleContexts(Automaton_commandsContext.class);
		}
		public Automaton_commandsContext automaton_commands(int i) {
			return getRuleContext(Automaton_commandsContext.class,i);
		}
		public For_loop_stateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_for_loop_state; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterFor_loop_state(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitFor_loop_state(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitFor_loop_state(this);
			else return visitor.visitChildren(this);
		}
	}

	public final For_loop_stateContext for_loop_state() throws RecognitionException {
		For_loop_stateContext _localctx = new For_loop_stateContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_for_loop_state);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(361);
			match(T__17);
			setState(362);
			((For_loop_stateContext)_localctx).elem = match(NAME);
			setState(363);
			match(T__31);
			setState(364);
			match(T__32);
			setState(365);
			list();
			setState(366);
			match(T__33);
			setState(376);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__36:
			case NAME:
				{
				setState(367);
				automaton_commands();
				}
				break;
			case T__1:
				{
				{
				setState(368);
				match(T__1);
				setState(372);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__36 || _la==NAME) {
					{
					{
					setState(369);
					automaton_commands();
					}
					}
					setState(374);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(375);
				match(T__2);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ListContext extends ParserRuleContext {
		public List<TerminalNode> NAME() { return getTokens(AdvParser.NAME); }
		public TerminalNode NAME(int i) {
			return getToken(AdvParser.NAME, i);
		}
		public ListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_list; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterList(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitList(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ListContext list() throws RecognitionException {
		ListContext _localctx = new ListContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(378);
			match(T__32);
			setState(379);
			match(NAME);
			setState(384);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__8) {
				{
				{
				setState(380);
				match(T__8);
				setState(381);
				match(NAME);
				}
				}
				setState(386);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(387);
			match(T__33);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class State_transitionsContext extends ParserRuleContext {
		public List<Automaton_transitionContext> automaton_transition() {
			return getRuleContexts(Automaton_transitionContext.class);
		}
		public Automaton_transitionContext automaton_transition(int i) {
			return getRuleContext(Automaton_transitionContext.class,i);
		}
		public State_transitionsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_state_transitions; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterState_transitions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitState_transitions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitState_transitions(this);
			else return visitor.visitChildren(this);
		}
	}

	public final State_transitionsContext state_transitions() throws RecognitionException {
		State_transitionsContext _localctx = new State_transitionsContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_state_transitions);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(389);
			match(T__34);
			setState(390);
			automaton_transition();
			setState(395);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__8) {
				{
				{
				setState(391);
				match(T__8);
				setState(392);
				automaton_transition();
				}
				}
				setState(397);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(398);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Automaton_transitionContext extends ParserRuleContext {
		public List<TerminalNode> NAME() { return getTokens(AdvParser.NAME); }
		public TerminalNode NAME(int i) {
			return getToken(AdvParser.NAME, i);
		}
		public List<TerminalNode> SYMBOL() { return getTokens(AdvParser.SYMBOL); }
		public TerminalNode SYMBOL(int i) {
			return getToken(AdvParser.SYMBOL, i);
		}
		public Automaton_transitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_automaton_transition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterAutomaton_transition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitAutomaton_transition(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitAutomaton_transition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Automaton_transitionContext automaton_transition() throws RecognitionException {
		Automaton_transitionContext _localctx = new Automaton_transitionContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_automaton_transition);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(400);
			match(NAME);
			setState(401);
			match(T__35);
			setState(402);
			match(SYMBOL);
			setState(407);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__8) {
				{
				{
				setState(403);
				match(T__8);
				setState(404);
				match(SYMBOL);
				}
				}
				setState(409);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(410);
			match(T__35);
			setState(411);
			match(NAME);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Change_state_propertyContext extends ParserRuleContext {
		public Token key;
		public Token value;
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public Change_state_propertyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_change_state_property; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterChange_state_property(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitChange_state_property(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitChange_state_property(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Change_state_propertyContext change_state_property() throws RecognitionException {
		Change_state_propertyContext _localctx = new Change_state_propertyContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_change_state_property);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(413);
			match(NAME);
			setState(414);
			match(T__9);
			setState(415);
			((Change_state_propertyContext)_localctx).key = _input.LT(1);
			_la = _input.LA(1);
			if ( !(_la==T__10 || _la==T__11) ) {
				((Change_state_propertyContext)_localctx).key = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(416);
			match(T__12);
			setState(417);
			((Change_state_propertyContext)_localctx).value = _input.LT(1);
			_la = _input.LA(1);
			if ( !(_la==T__13 || _la==T__14) ) {
				((Change_state_propertyContext)_localctx).value = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(418);
			match(T__15);
			setState(419);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Declare_statesContext extends ParserRuleContext {
		public List<TerminalNode> NAME() { return getTokens(AdvParser.NAME); }
		public TerminalNode NAME(int i) {
			return getToken(AdvParser.NAME, i);
		}
		public Declare_statesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declare_states; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterDeclare_states(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitDeclare_states(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitDeclare_states(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Declare_statesContext declare_states() throws RecognitionException {
		Declare_statesContext _localctx = new Declare_statesContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_declare_states);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(421);
			match(T__36);
			setState(422);
			match(NAME);
			setState(427);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__8) {
				{
				{
				setState(423);
				match(T__8);
				setState(424);
				match(NAME);
				}
				}
				setState(429);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(430);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Decl_automatonContext extends ParserRuleContext {
		public Automaton_typesContext automaton_types() {
			return getRuleContext(Automaton_typesContext.class,0);
		}
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public Decl_automatonContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decl_automaton; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterDecl_automaton(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitDecl_automaton(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitDecl_automaton(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Decl_automatonContext decl_automaton() throws RecognitionException {
		Decl_automatonContext _localctx = new Decl_automatonContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_decl_automaton);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(432);
			automaton_types();
			setState(433);
			match(NAME);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AlphabetContext extends ParserRuleContext {
		public List<TerminalNode> SYMBOL() { return getTokens(AdvParser.SYMBOL); }
		public TerminalNode SYMBOL(int i) {
			return getToken(AdvParser.SYMBOL, i);
		}
		public AlphabetContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alphabet; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterAlphabet(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitAlphabet(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitAlphabet(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AlphabetContext alphabet() throws RecognitionException {
		AlphabetContext _localctx = new AlphabetContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_alphabet);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(435);
			match(T__37);
			setState(436);
			match(T__32);
			setState(437);
			match(SYMBOL);
			setState(442);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__8) {
				{
				{
				setState(438);
				match(T__8);
				setState(439);
				match(SYMBOL);
				}
				}
				setState(444);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(445);
			match(T__33);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TransitionContext extends ParserRuleContext {
		public List<TerminalNode> NAME() { return getTokens(AdvParser.NAME); }
		public TerminalNode NAME(int i) {
			return getToken(AdvParser.NAME, i);
		}
		public TransitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_transition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterTransition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitTransition(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitTransition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TransitionContext transition() throws RecognitionException {
		TransitionContext _localctx = new TransitionContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_transition);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(447);
			match(T__38);
			setState(448);
			match(NAME);
			setState(449);
			match(T__8);
			setState(450);
			match(NAME);
			setState(451);
			match(T__39);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VectorContext extends ParserRuleContext {
		public Cart_vectorContext cart_vector() {
			return getRuleContext(Cart_vectorContext.class,0);
		}
		public Polar_vectorContext polar_vector() {
			return getRuleContext(Polar_vectorContext.class,0);
		}
		public VectorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_vector; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterVector(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitVector(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitVector(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VectorContext vector() throws RecognitionException {
		VectorContext _localctx = new VectorContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_vector);
		try {
			setState(455);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,35,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(453);
				cart_vector();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(454);
				polar_vector();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Cart_vectorContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public Cart_vectorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cart_vector; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterCart_vector(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitCart_vector(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitCart_vector(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Cart_vectorContext cart_vector() throws RecognitionException {
		Cart_vectorContext _localctx = new Cart_vectorContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_cart_vector);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(457);
			match(T__22);
			setState(458);
			expr(0);
			setState(459);
			match(T__8);
			setState(460);
			expr(0);
			setState(461);
			match(T__23);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Polar_vectorContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public Polar_vectorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_polar_vector; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterPolar_vector(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitPolar_vector(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitPolar_vector(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Polar_vectorContext polar_vector() throws RecognitionException {
		Polar_vectorContext _localctx = new Polar_vectorContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_polar_vector);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(463);
			match(T__22);
			setState(464);
			expr(0);
			setState(465);
			match(T__40);
			setState(466);
			expr(0);
			setState(467);
			match(T__23);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprContext extends ParserRuleContext {
		public Type t = null;
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	 
		public ExprContext() { }
		public void copyFrom(ExprContext ctx) {
			super.copyFrom(ctx);
			this.t = ctx.t;
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExprAddSubContext extends ExprContext {
		public Token op;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ExprAddSubContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterExprAddSub(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitExprAddSub(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitExprAddSub(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExprParenthesisContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ExprParenthesisContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterExprParenthesis(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitExprParenthesis(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitExprParenthesis(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExprNumberContext extends ExprContext {
		public NumberContext number() {
			return getRuleContext(NumberContext.class,0);
		}
		public ExprNumberContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterExprNumber(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitExprNumber(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitExprNumber(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExprNameContext extends ExprContext {
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public ExprNameContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterExprName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitExprName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitExprName(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExprPositiveNegativeContext extends ExprContext {
		public Token op;
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ExprPositiveNegativeContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterExprPositiveNegative(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitExprPositiveNegative(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitExprPositiveNegative(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExprMulDivContext extends ExprContext {
		public Token op;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ExprMulDivContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterExprMulDiv(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitExprMulDiv(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitExprMulDiv(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExprVectorContext extends ExprContext {
		public VectorContext vector() {
			return getRuleContext(VectorContext.class,0);
		}
		public ExprVectorContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterExprVector(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitExprVector(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitExprVector(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 88;
		enterRecursionRule(_localctx, 88, RULE_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(479);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,36,_ctx) ) {
			case 1:
				{
				_localctx = new ExprParenthesisContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(470);
				match(T__22);
				setState(471);
				expr(0);
				setState(472);
				match(T__23);
				}
				break;
			case 2:
				{
				_localctx = new ExprPositiveNegativeContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(474);
				((ExprPositiveNegativeContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==T__43 || _la==T__44) ) {
					((ExprPositiveNegativeContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(475);
				expr(4);
				}
				break;
			case 3:
				{
				_localctx = new ExprNumberContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(476);
				number();
				}
				break;
			case 4:
				{
				_localctx = new ExprVectorContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(477);
				vector();
				}
				break;
			case 5:
				{
				_localctx = new ExprNameContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(478);
				match(NAME);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(489);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,38,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(487);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,37,_ctx) ) {
					case 1:
						{
						_localctx = new ExprMulDivContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(481);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(482);
						((ExprMulDivContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__41 || _la==T__42) ) {
							((ExprMulDivContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(483);
						expr(7);
						}
						break;
					case 2:
						{
						_localctx = new ExprAddSubContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(484);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(485);
						((ExprAddSubContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__43 || _la==T__44) ) {
							((ExprAddSubContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(486);
						expr(6);
						}
						break;
					}
					} 
				}
				setState(491);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,38,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Keypair_valueContext extends ParserRuleContext {
		public NumberContext number() {
			return getRuleContext(NumberContext.class,0);
		}
		public TerminalNode NAME() { return getToken(AdvParser.NAME, 0); }
		public Keypair_valueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_keypair_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterKeypair_value(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitKeypair_value(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitKeypair_value(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Keypair_valueContext keypair_value() throws RecognitionException {
		Keypair_valueContext _localctx = new Keypair_valueContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_keypair_value);
		try {
			setState(494);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
			case REAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(492);
				number();
				}
				break;
			case NAME:
				enterOuterAlt(_localctx, 2);
				{
				setState(493);
				match(NAME);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NumberContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(AdvParser.INT, 0); }
		public TerminalNode REAL() { return getToken(AdvParser.REAL, 0); }
		public NumberContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_number; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterNumber(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitNumber(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitNumber(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumberContext number() throws RecognitionException {
		NumberContext _localctx = new NumberContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_number);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(496);
			_la = _input.LA(1);
			if ( !(_la==INT || _la==REAL) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Automaton_typesContext extends ParserRuleContext {
		public Automaton_typesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_automaton_types; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).enterAutomaton_types(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof AdvListener ) ((AdvListener)listener).exitAutomaton_types(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof AdvVisitor ) return ((AdvVisitor<? extends T>)visitor).visitAutomaton_types(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Automaton_typesContext automaton_types() throws RecognitionException {
		Automaton_typesContext _localctx = new Automaton_typesContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_automaton_types);
		int _la;
		try {
			setState(503);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__45:
				enterOuterAlt(_localctx, 1);
				{
				setState(498);
				match(T__45);
				}
				break;
			case T__46:
			case T__47:
				enterOuterAlt(_localctx, 2);
				{
				{
				setState(500);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__46) {
					{
					setState(499);
					match(T__46);
					}
				}

				setState(502);
				match(T__47);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 44:
			return expr_sempred((ExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 6);
		case 1:
			return precpred(_ctx, 5);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u00018\u01fa\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007\u0012"+
		"\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007\u0015"+
		"\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007\u0018"+
		"\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007\u001b"+
		"\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007\u001e"+
		"\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0002\"\u0007\"\u0002"+
		"#\u0007#\u0002$\u0007$\u0002%\u0007%\u0002&\u0007&\u0002\'\u0007\'\u0002"+
		"(\u0007(\u0002)\u0007)\u0002*\u0007*\u0002+\u0007+\u0002,\u0007,\u0002"+
		"-\u0007-\u0002.\u0007.\u0002/\u0007/\u0001\u0000\u0001\u0000\u0004\u0000"+
		"c\b\u0000\u000b\u0000\f\u0000d\u0001\u0001\u0004\u0001h\b\u0001\u000b"+
		"\u0001\f\u0001i\u0001\u0001\u0004\u0001m\b\u0001\u000b\u0001\f\u0001n"+
		"\u0001\u0001\u0004\u0001r\b\u0001\u000b\u0001\f\u0001s\u0001\u0001\u0004"+
		"\u0001w\b\u0001\u000b\u0001\f\u0001x\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0004"+
		"\u0001\u0004\u0001\u0004\u0001\u0005\u0004\u0005\u0087\b\u0005\u000b\u0005"+
		"\f\u0005\u0088\u0001\u0005\u0004\u0005\u008c\b\u0005\u000b\u0005\f\u0005"+
		"\u008d\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0004\u0006\u0094"+
		"\b\u0006\u000b\u0006\f\u0006\u0095\u0001\u0006\u0001\u0006\u0001\u0007"+
		"\u0001\u0007\u0001\u0007\u0003\u0007\u009d\b\u0007\u0001\b\u0001\b\u0001"+
		"\b\u0001\t\u0001\t\u0001\t\u0001\t\u0005\t\u00a6\b\t\n\t\f\t\u00a9\t\t"+
		"\u0001\t\u0001\t\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0003"+
		"\n\u00b3\b\n\u0001\n\u0003\n\u00b6\b\n\u0001\u000b\u0001\u000b\u0001\u000b"+
		"\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b"+
		"\u0001\u000b\u0001\u000b\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001"+
		"\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\r\u0001\r\u0004\r\u00dd\b\r\u000b\r\f\r\u00de\u0001\u000e\u0001"+
		"\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001"+
		"\u000e\u0001\u000e\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001"+
		"\u000f\u0001\u000f\u0001\u000f\u0005\u000f\u00f1\b\u000f\n\u000f\f\u000f"+
		"\u00f4\t\u000f\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0005\u0010"+
		"\u00fa\b\u0010\n\u0010\f\u0010\u00fd\t\u0010\u0001\u0011\u0001\u0011\u0001"+
		"\u0011\u0001\u0011\u0001\u0011\u0001\u0012\u0001\u0012\u0001\u0012\u0001"+
		"\u0012\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0003"+
		"\u0013\u010d\b\u0013\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0005\u0014\u0118"+
		"\b\u0014\n\u0014\f\u0014\u011b\t\u0014\u0001\u0015\u0001\u0015\u0003\u0015"+
		"\u011f\b\u0015\u0001\u0016\u0001\u0016\u0003\u0016\u0123\b\u0016\u0001"+
		"\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0018\u0001\u0018\u0001"+
		"\u0018\u0005\u0018\u012c\b\u0018\n\u0018\f\u0018\u012f\t\u0018\u0001\u0019"+
		"\u0001\u0019\u0001\u0019\u0004\u0019\u0134\b\u0019\u000b\u0019\f\u0019"+
		"\u0135\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001b\u0001"+
		"\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001c\u0001\u001c\u0001"+
		"\u001c\u0001\u001c\u0001\u001c\u0001\u001d\u0004\u001d\u0147\b\u001d\u000b"+
		"\u001d\f\u001d\u0148\u0001\u001d\u0001\u001d\u0005\u001d\u014d\b\u001d"+
		"\n\u001d\f\u001d\u0150\t\u001d\u0001\u001d\u0001\u001d\u0001\u001e\u0001"+
		"\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0001"+
		"\u001e\u0001\u001e\u0005\u001e\u015d\b\u001e\n\u001e\f\u001e\u0160\t\u001e"+
		"\u0001\u001e\u0003\u001e\u0163\b\u001e\u0001\u001f\u0001\u001f\u0001\u001f"+
		"\u0003\u001f\u0168\b\u001f\u0001 \u0001 \u0001 \u0001 \u0001 \u0001 \u0001"+
		" \u0001 \u0001 \u0005 \u0173\b \n \f \u0176\t \u0001 \u0003 \u0179\b "+
		"\u0001!\u0001!\u0001!\u0001!\u0005!\u017f\b!\n!\f!\u0182\t!\u0001!\u0001"+
		"!\u0001\"\u0001\"\u0001\"\u0001\"\u0005\"\u018a\b\"\n\"\f\"\u018d\t\""+
		"\u0001\"\u0001\"\u0001#\u0001#\u0001#\u0001#\u0001#\u0005#\u0196\b#\n"+
		"#\f#\u0199\t#\u0001#\u0001#\u0001#\u0001$\u0001$\u0001$\u0001$\u0001$"+
		"\u0001$\u0001$\u0001$\u0001%\u0001%\u0001%\u0001%\u0005%\u01aa\b%\n%\f"+
		"%\u01ad\t%\u0001%\u0001%\u0001&\u0001&\u0001&\u0001\'\u0001\'\u0001\'"+
		"\u0001\'\u0001\'\u0005\'\u01b9\b\'\n\'\f\'\u01bc\t\'\u0001\'\u0001\'\u0001"+
		"(\u0001(\u0001(\u0001(\u0001(\u0001(\u0001)\u0001)\u0003)\u01c8\b)\u0001"+
		"*\u0001*\u0001*\u0001*\u0001*\u0001*\u0001+\u0001+\u0001+\u0001+\u0001"+
		"+\u0001+\u0001,\u0001,\u0001,\u0001,\u0001,\u0001,\u0001,\u0001,\u0001"+
		",\u0001,\u0003,\u01e0\b,\u0001,\u0001,\u0001,\u0001,\u0001,\u0001,\u0005"+
		",\u01e8\b,\n,\f,\u01eb\t,\u0001-\u0001-\u0003-\u01ef\b-\u0001.\u0001."+
		"\u0001/\u0001/\u0003/\u01f5\b/\u0001/\u0003/\u01f8\b/\u0001/\u0000\u0001"+
		"X0\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a"+
		"\u001c\u001e \"$&(*,.02468:<>@BDFHJLNPRTVXZ\\^\u0000\u0006\u0001\u0000"+
		"\u000b\f\u0001\u0000\u000e\u000f\u0002\u0000\u0014\u0014\u001a\u001a\u0001"+
		"\u0000,-\u0001\u0000*+\u0001\u000023\u01fe\u0000`\u0001\u0000\u0000\u0000"+
		"\u0002g\u0001\u0000\u0000\u0000\u0004z\u0001\u0000\u0000\u0000\u0006}"+
		"\u0001\u0000\u0000\u0000\b\u0082\u0001\u0000\u0000\u0000\n\u0086\u0001"+
		"\u0000\u0000\u0000\f\u008f\u0001\u0000\u0000\u0000\u000e\u009c\u0001\u0000"+
		"\u0000\u0000\u0010\u009e\u0001\u0000\u0000\u0000\u0012\u00a1\u0001\u0000"+
		"\u0000\u0000\u0014\u00b5\u0001\u0000\u0000\u0000\u0016\u00b7\u0001\u0000"+
		"\u0000\u0000\u0018\u00c2\u0001\u0000\u0000\u0000\u001a\u00dc\u0001\u0000"+
		"\u0000\u0000\u001c\u00e0\u0001\u0000\u0000\u0000\u001e\u00e9\u0001\u0000"+
		"\u0000\u0000 \u00f5\u0001\u0000\u0000\u0000\"\u00fe\u0001\u0000\u0000"+
		"\u0000$\u0103\u0001\u0000\u0000\u0000&\u010c\u0001\u0000\u0000\u0000("+
		"\u010e\u0001\u0000\u0000\u0000*\u011e\u0001\u0000\u0000\u0000,\u0122\u0001"+
		"\u0000\u0000\u0000.\u0124\u0001\u0000\u0000\u00000\u0128\u0001\u0000\u0000"+
		"\u00002\u0130\u0001\u0000\u0000\u00004\u0137\u0001\u0000\u0000\u00006"+
		"\u013b\u0001\u0000\u0000\u00008\u0140\u0001\u0000\u0000\u0000:\u0146\u0001"+
		"\u0000\u0000\u0000<\u0153\u0001\u0000\u0000\u0000>\u0167\u0001\u0000\u0000"+
		"\u0000@\u0169\u0001\u0000\u0000\u0000B\u017a\u0001\u0000\u0000\u0000D"+
		"\u0185\u0001\u0000\u0000\u0000F\u0190\u0001\u0000\u0000\u0000H\u019d\u0001"+
		"\u0000\u0000\u0000J\u01a5\u0001\u0000\u0000\u0000L\u01b0\u0001\u0000\u0000"+
		"\u0000N\u01b3\u0001\u0000\u0000\u0000P\u01bf\u0001\u0000\u0000\u0000R"+
		"\u01c7\u0001\u0000\u0000\u0000T\u01c9\u0001\u0000\u0000\u0000V\u01cf\u0001"+
		"\u0000\u0000\u0000X\u01df\u0001\u0000\u0000\u0000Z\u01ee\u0001\u0000\u0000"+
		"\u0000\\\u01f0\u0001\u0000\u0000\u0000^\u01f7\u0001\u0000\u0000\u0000"+
		"`b\u0003N\'\u0000ac\u0003\u0002\u0001\u0000ba\u0001\u0000\u0000\u0000"+
		"cd\u0001\u0000\u0000\u0000db\u0001\u0000\u0000\u0000de\u0001\u0000\u0000"+
		"\u0000e\u0001\u0001\u0000\u0000\u0000fh\u00038\u001c\u0000gf\u0001\u0000"+
		"\u0000\u0000hi\u0001\u0000\u0000\u0000ig\u0001\u0000\u0000\u0000ij\u0001"+
		"\u0000\u0000\u0000jl\u0001\u0000\u0000\u0000km\u0003\u0018\f\u0000lk\u0001"+
		"\u0000\u0000\u0000mn\u0001\u0000\u0000\u0000nl\u0001\u0000\u0000\u0000"+
		"no\u0001\u0000\u0000\u0000oq\u0001\u0000\u0000\u0000pr\u0003\u0006\u0003"+
		"\u0000qp\u0001\u0000\u0000\u0000rs\u0001\u0000\u0000\u0000sq\u0001\u0000"+
		"\u0000\u0000st\u0001\u0000\u0000\u0000tv\u0001\u0000\u0000\u0000uw\u0003"+
		"\u0004\u0002\u0000vu\u0001\u0000\u0000\u0000wx\u0001\u0000\u0000\u0000"+
		"xv\u0001\u0000\u0000\u0000xy\u0001\u0000\u0000\u0000y\u0003\u0001\u0000"+
		"\u0000\u0000z{\u0005\u0001\u0000\u0000{|\u00056\u0000\u0000|\u0005\u0001"+
		"\u0000\u0000\u0000}~\u0003\b\u0004\u0000~\u007f\u0005\u0002\u0000\u0000"+
		"\u007f\u0080\u0003\n\u0005\u0000\u0080\u0081\u0005\u0003\u0000\u0000\u0081"+
		"\u0007\u0001\u0000\u0000\u0000\u0082\u0083\u0005\u0004\u0000\u0000\u0083"+
		"\u0084\u00056\u0000\u0000\u0084\t\u0001\u0000\u0000\u0000\u0085\u0087"+
		"\u0003\u0016\u000b\u0000\u0086\u0085\u0001\u0000\u0000\u0000\u0087\u0088"+
		"\u0001\u0000\u0000\u0000\u0088\u0086\u0001\u0000\u0000\u0000\u0088\u0089"+
		"\u0001\u0000\u0000\u0000\u0089\u008b\u0001\u0000\u0000\u0000\u008a\u008c"+
		"\u0003\f\u0006\u0000\u008b\u008a\u0001\u0000\u0000\u0000\u008c\u008d\u0001"+
		"\u0000\u0000\u0000\u008d\u008b\u0001\u0000\u0000\u0000\u008d\u008e\u0001"+
		"\u0000\u0000\u0000\u008e\u000b\u0001\u0000\u0000\u0000\u008f\u0090\u0005"+
		"\u0005\u0000\u0000\u0090\u0091\u00056\u0000\u0000\u0091\u0093\u0005\u0002"+
		"\u0000\u0000\u0092\u0094\u0003\u000e\u0007\u0000\u0093\u0092\u0001\u0000"+
		"\u0000\u0000\u0094\u0095\u0001\u0000\u0000\u0000\u0095\u0093\u0001\u0000"+
		"\u0000\u0000\u0095\u0096\u0001\u0000\u0000\u0000\u0096\u0097\u0001\u0000"+
		"\u0000\u0000\u0097\u0098\u0005\u0003\u0000\u0000\u0098\r\u0001\u0000\u0000"+
		"\u0000\u0099\u009d\u0003\u0012\t\u0000\u009a\u009d\u0003\u0010\b\u0000"+
		"\u009b\u009d\u0003<\u001e\u0000\u009c\u0099\u0001\u0000\u0000\u0000\u009c"+
		"\u009a\u0001\u0000\u0000\u0000\u009c\u009b\u0001\u0000\u0000\u0000\u009d"+
		"\u000f\u0001\u0000\u0000\u0000\u009e\u009f\u0005\u0006\u0000\u0000\u009f"+
		"\u00a0\u0005\u0007\u0000\u0000\u00a0\u0011\u0001\u0000\u0000\u0000\u00a1"+
		"\u00a2\u0005\b\u0000\u0000\u00a2\u00a7\u0003\u0014\n\u0000\u00a3\u00a4"+
		"\u0005\t\u0000\u0000\u00a4\u00a6\u0003\u0014\n\u0000\u00a5\u00a3\u0001"+
		"\u0000\u0000\u0000\u00a6\u00a9\u0001\u0000\u0000\u0000\u00a7\u00a5\u0001"+
		"\u0000\u0000\u0000\u00a7\u00a8\u0001\u0000\u0000\u0000\u00a8\u00aa\u0001"+
		"\u0000\u0000\u0000\u00a9\u00a7\u0001\u0000\u0000\u0000\u00aa\u00ab\u0005"+
		"\u0007\u0000\u0000\u00ab\u0013\u0001\u0000\u0000\u0000\u00ac\u00b2\u0005"+
		"6\u0000\u0000\u00ad\u00ae\u0005\n\u0000\u0000\u00ae\u00af\u0007\u0000"+
		"\u0000\u0000\u00af\u00b0\u0005\r\u0000\u0000\u00b0\u00b1\u0007\u0001\u0000"+
		"\u0000\u00b1\u00b3\u0005\u0010\u0000\u0000\u00b2\u00ad\u0001\u0000\u0000"+
		"\u0000\u00b2\u00b3\u0001\u0000\u0000\u0000\u00b3\u00b6\u0001\u0000\u0000"+
		"\u0000\u00b4\u00b6\u0003P(\u0000\u00b5\u00ac\u0001\u0000\u0000\u0000\u00b5"+
		"\u00b4\u0001\u0000\u0000\u0000\u00b6\u0015\u0001\u0000\u0000\u0000\u00b7"+
		"\u00b8\u0005\u0011\u0000\u0000\u00b8\u00b9\u00056\u0000\u0000\u00b9\u00ba"+
		"\u0005\u0012\u0000\u0000\u00ba\u00bb\u00056\u0000\u0000\u00bb\u00bc\u0005"+
		"\u0013\u0000\u0000\u00bc\u00bd\u0003T*\u0000\u00bd\u00be\u0005\u0014\u0000"+
		"\u0000\u00be\u00bf\u0005\u0015\u0000\u0000\u00bf\u00c0\u0003T*\u0000\u00c0"+
		"\u00c1\u0005\u0007\u0000\u0000\u00c1\u0017\u0001\u0000\u0000\u0000\u00c2"+
		"\u00c3\u00036\u001b\u0000\u00c3\u00c4\u0005\u0002\u0000\u0000\u00c4\u00c5"+
		"\u0003\u001a\r\u0000\u00c5\u00c6\u0005\u0003\u0000\u0000\u00c6\u0019\u0001"+
		"\u0000\u0000\u0000\u00c7\u00c8\u0003(\u0014\u0000\u00c8\u00c9\u0005\u0007"+
		"\u0000\u0000\u00c9\u00dd\u0001\u0000\u0000\u0000\u00ca\u00cb\u0003 \u0010"+
		"\u0000\u00cb\u00cc\u0005\u0007\u0000\u0000\u00cc\u00dd\u0001\u0000\u0000"+
		"\u0000\u00cd\u00ce\u0003\"\u0011\u0000\u00ce\u00cf\u0005\u0007\u0000\u0000"+
		"\u00cf\u00dd\u0001\u0000\u0000\u0000\u00d0\u00d1\u0003$\u0012\u0000\u00d1"+
		"\u00d2\u0005\u0007\u0000\u0000\u00d2\u00dd\u0001\u0000\u0000\u0000\u00d3"+
		"\u00d4\u0003\u001e\u000f\u0000\u00d4\u00d5\u0005\u0007\u0000\u0000\u00d5"+
		"\u00dd\u0001\u0000\u0000\u0000\u00d6\u00d7\u0003\u001c\u000e\u0000\u00d7"+
		"\u00d8\u0005\u0007\u0000\u0000\u00d8\u00dd\u0001\u0000\u0000\u0000\u00d9"+
		"\u00da\u00034\u001a\u0000\u00da\u00db\u0005\u0007\u0000\u0000\u00db\u00dd"+
		"\u0001\u0000\u0000\u0000\u00dc\u00c7\u0001\u0000\u0000\u0000\u00dc\u00ca"+
		"\u0001\u0000\u0000\u0000\u00dc\u00cd\u0001\u0000\u0000\u0000\u00dc\u00d0"+
		"\u0001\u0000\u0000\u0000\u00dc\u00d3\u0001\u0000\u0000\u0000\u00dc\u00d6"+
		"\u0001\u0000\u0000\u0000\u00dc\u00d9\u0001\u0000\u0000\u0000\u00dd\u00de"+
		"\u0001\u0000\u0000\u0000\u00de\u00dc\u0001\u0000\u0000\u0000\u00de\u00df"+
		"\u0001\u0000\u0000\u0000\u00df\u001b\u0001\u0000\u0000\u0000\u00e0\u00e1"+
		"\u0005\u0016\u0000\u0000\u00e1\u00e2\u00056\u0000\u0000\u00e2\u00e3\u0005"+
		"\u0017\u0000\u0000\u00e3\u00e4\u00052\u0000\u0000\u00e4\u00e5\u0005\t"+
		"\u0000\u0000\u00e5\u00e6\u00052\u0000\u0000\u00e6\u00e7\u0005\u0018\u0000"+
		"\u0000\u00e7\u00e8\u0003.\u0017\u0000\u00e8\u001d\u0001\u0000\u0000\u0000"+
		"\u00e9\u00ea\u0003P(\u0000\u00ea\u00eb\u0005\u0019\u0000\u0000\u00eb\u00ec"+
		"\u0003&\u0013\u0000\u00ec\u00ed\u0007\u0002\u0000\u0000\u00ed\u00f2\u0003"+
		"&\u0013\u0000\u00ee\u00ef\u0007\u0002\u0000\u0000\u00ef\u00f1\u0003&\u0013"+
		"\u0000\u00f0\u00ee\u0001\u0000\u0000\u0000\u00f1\u00f4\u0001\u0000\u0000"+
		"\u0000\u00f2\u00f0\u0001\u0000\u0000\u0000\u00f2\u00f3\u0001\u0000\u0000"+
		"\u0000\u00f3\u001f\u0001\u0000\u0000\u0000\u00f4\u00f2\u0001\u0000\u0000"+
		"\u0000\u00f5\u00f6\u0005\u001b\u0000\u0000\u00f6\u00fb\u00056\u0000\u0000"+
		"\u00f7\u00f8\u0005\t\u0000\u0000\u00f8\u00fa\u00056\u0000\u0000\u00f9"+
		"\u00f7\u0001\u0000\u0000\u0000\u00fa\u00fd\u0001\u0000\u0000\u0000\u00fb"+
		"\u00f9\u0001\u0000\u0000\u0000\u00fb\u00fc\u0001\u0000\u0000\u0000\u00fc"+
		"!\u0001\u0000\u0000\u0000\u00fd\u00fb\u0001\u0000\u0000\u0000\u00fe\u00ff"+
		"\u0005\u001b\u0000\u0000\u00ff\u0100\u00056\u0000\u0000\u0100\u0101\u0005"+
		"\r\u0000\u0000\u0101\u0102\u0003&\u0013\u0000\u0102#\u0001\u0000\u0000"+
		"\u0000\u0103\u0104\u00056\u0000\u0000\u0104\u0105\u0005\r\u0000\u0000"+
		"\u0105\u0106\u0003&\u0013\u0000\u0106%\u0001\u0000\u0000\u0000\u0107\u0108"+
		"\u0005\u0017\u0000\u0000\u0108\u0109\u00056\u0000\u0000\u0109\u010d\u0005"+
		"\u0018\u0000\u0000\u010a\u010d\u0003R)\u0000\u010b\u010d\u0003X,\u0000"+
		"\u010c\u0107\u0001\u0000\u0000\u0000\u010c\u010a\u0001\u0000\u0000\u0000"+
		"\u010c\u010b\u0001\u0000\u0000\u0000\u010d\'\u0001\u0000\u0000\u0000\u010e"+
		"\u010f\u0005\u001c\u0000\u0000\u010f\u0110\u0003,\u0016\u0000\u0110\u0111"+
		"\u0005\u0013\u0000\u0000\u0111\u0119\u0003*\u0015\u0000\u0112\u0113\u0005"+
		"\t\u0000\u0000\u0113\u0114\u0003,\u0016\u0000\u0114\u0115\u0005\u0013"+
		"\u0000\u0000\u0115\u0116\u0003*\u0015\u0000\u0116\u0118\u0001\u0000\u0000"+
		"\u0000\u0117\u0112\u0001\u0000\u0000\u0000\u0118\u011b\u0001\u0000\u0000"+
		"\u0000\u0119\u0117\u0001\u0000\u0000\u0000\u0119\u011a\u0001\u0000\u0000"+
		"\u0000\u011a)\u0001\u0000\u0000\u0000\u011b\u0119\u0001\u0000\u0000\u0000"+
		"\u011c\u011f\u0003R)\u0000\u011d\u011f\u00056\u0000\u0000\u011e\u011c"+
		"\u0001\u0000\u0000\u0000\u011e\u011d\u0001\u0000\u0000\u0000\u011f+\u0001"+
		"\u0000\u0000\u0000\u0120\u0123\u00056\u0000\u0000\u0121\u0123\u00034\u001a"+
		"\u0000\u0122\u0120\u0001\u0000\u0000\u0000\u0122\u0121\u0001\u0000\u0000"+
		"\u0000\u0123-\u0001\u0000\u0000\u0000\u0124\u0125\u0005\n\u0000\u0000"+
		"\u0125\u0126\u00030\u0018\u0000\u0126\u0127\u0005\u0010\u0000\u0000\u0127"+
		"/\u0001\u0000\u0000\u0000\u0128\u012d\u00032\u0019\u0000\u0129\u012a\u0005"+
		"\t\u0000\u0000\u012a\u012c\u00032\u0019\u0000\u012b\u0129\u0001\u0000"+
		"\u0000\u0000\u012c\u012f\u0001\u0000\u0000\u0000\u012d\u012b\u0001\u0000"+
		"\u0000\u0000\u012d\u012e\u0001\u0000\u0000\u0000\u012e1\u0001\u0000\u0000"+
		"\u0000\u012f\u012d\u0001\u0000\u0000\u0000\u0130\u0131\u00056\u0000\u0000"+
		"\u0131\u0133\u0005\r\u0000\u0000\u0132\u0134\u0003Z-\u0000\u0133\u0132"+
		"\u0001\u0000\u0000\u0000\u0134\u0135\u0001\u0000\u0000\u0000\u0135\u0133"+
		"\u0001\u0000\u0000\u0000\u0135\u0136\u0001\u0000\u0000\u0000\u01363\u0001"+
		"\u0000\u0000\u0000\u0137\u0138\u0003P(\u0000\u0138\u0139\u0005\u001d\u0000"+
		"\u0000\u0139\u013a\u0003.\u0017\u0000\u013a5\u0001\u0000\u0000\u0000\u013b"+
		"\u013c\u0005\u001e\u0000\u0000\u013c\u013d\u00056\u0000\u0000\u013d\u013e"+
		"\u0005\u001f\u0000\u0000\u013e\u013f\u00056\u0000\u0000\u013f7\u0001\u0000"+
		"\u0000\u0000\u0140\u0141\u0003L&\u0000\u0141\u0142\u0005\u0002\u0000\u0000"+
		"\u0142\u0143\u0003:\u001d\u0000\u0143\u0144\u0005\u0003\u0000\u0000\u0144"+
		"9\u0001\u0000\u0000\u0000\u0145\u0147\u0003J%\u0000\u0146\u0145\u0001"+
		"\u0000\u0000\u0000\u0147\u0148\u0001\u0000\u0000\u0000\u0148\u0146\u0001"+
		"\u0000\u0000\u0000\u0148\u0149\u0001\u0000\u0000\u0000\u0149\u014e\u0001"+
		"\u0000\u0000\u0000\u014a\u014d\u0003H$\u0000\u014b\u014d\u0003@ \u0000"+
		"\u014c\u014a\u0001\u0000\u0000\u0000\u014c\u014b\u0001\u0000\u0000\u0000"+
		"\u014d\u0150\u0001\u0000\u0000\u0000\u014e\u014c\u0001\u0000\u0000\u0000"+
		"\u014e\u014f\u0001\u0000\u0000\u0000\u014f\u0151\u0001\u0000\u0000\u0000"+
		"\u0150\u014e\u0001\u0000\u0000\u0000\u0151\u0152\u0003D\"\u0000\u0152"+
		";\u0001\u0000\u0000\u0000\u0153\u0154\u0005\u0012\u0000\u0000\u0154\u0155"+
		"\u00056\u0000\u0000\u0155\u0156\u0005 \u0000\u0000\u0156\u0157\u0005!"+
		"\u0000\u0000\u0157\u0158\u0003B!\u0000\u0158\u0162\u0005\"\u0000\u0000"+
		"\u0159\u0163\u0003\u000e\u0007\u0000\u015a\u015e\u0005\u0002\u0000\u0000"+
		"\u015b\u015d\u0003\u000e\u0007\u0000\u015c\u015b\u0001\u0000\u0000\u0000"+
		"\u015d\u0160\u0001\u0000\u0000\u0000\u015e\u015c\u0001\u0000\u0000\u0000"+
		"\u015e\u015f\u0001\u0000\u0000\u0000\u015f\u0161\u0001\u0000\u0000\u0000"+
		"\u0160\u015e\u0001\u0000\u0000\u0000\u0161\u0163\u0005\u0003\u0000\u0000"+
		"\u0162\u0159\u0001\u0000\u0000\u0000\u0162\u015a\u0001\u0000\u0000\u0000"+
		"\u0163=\u0001\u0000\u0000\u0000\u0164\u0168\u0003F#\u0000\u0165\u0168"+
		"\u0003H$\u0000\u0166\u0168\u0003J%\u0000\u0167\u0164\u0001\u0000\u0000"+
		"\u0000\u0167\u0165\u0001\u0000\u0000\u0000\u0167\u0166\u0001\u0000\u0000"+
		"\u0000\u0168?\u0001\u0000\u0000\u0000\u0169\u016a\u0005\u0012\u0000\u0000"+
		"\u016a\u016b\u00056\u0000\u0000\u016b\u016c\u0005 \u0000\u0000\u016c\u016d"+
		"\u0005!\u0000\u0000\u016d\u016e\u0003B!\u0000\u016e\u0178\u0005\"\u0000"+
		"\u0000\u016f\u0179\u0003>\u001f\u0000\u0170\u0174\u0005\u0002\u0000\u0000"+
		"\u0171\u0173\u0003>\u001f\u0000\u0172\u0171\u0001\u0000\u0000\u0000\u0173"+
		"\u0176\u0001\u0000\u0000\u0000\u0174\u0172\u0001\u0000\u0000\u0000\u0174"+
		"\u0175\u0001\u0000\u0000\u0000\u0175\u0177\u0001\u0000\u0000\u0000\u0176"+
		"\u0174\u0001\u0000\u0000\u0000\u0177\u0179\u0005\u0003\u0000\u0000\u0178"+
		"\u016f\u0001\u0000\u0000\u0000\u0178\u0170\u0001\u0000\u0000\u0000\u0179"+
		"A\u0001\u0000\u0000\u0000\u017a\u017b\u0005!\u0000\u0000\u017b\u0180\u0005"+
		"6\u0000\u0000\u017c\u017d\u0005\t\u0000\u0000\u017d\u017f\u00056\u0000"+
		"\u0000\u017e\u017c\u0001\u0000\u0000\u0000\u017f\u0182\u0001\u0000\u0000"+
		"\u0000\u0180\u017e\u0001\u0000\u0000\u0000\u0180\u0181\u0001\u0000\u0000"+
		"\u0000\u0181\u0183\u0001\u0000\u0000\u0000\u0182\u0180\u0001\u0000\u0000"+
		"\u0000\u0183\u0184\u0005\"\u0000\u0000\u0184C\u0001\u0000\u0000\u0000"+
		"\u0185\u0186\u0005#\u0000\u0000\u0186\u018b\u0003F#\u0000\u0187\u0188"+
		"\u0005\t\u0000\u0000\u0188\u018a\u0003F#\u0000\u0189\u0187\u0001\u0000"+
		"\u0000\u0000\u018a\u018d\u0001\u0000\u0000\u0000\u018b\u0189\u0001\u0000"+
		"\u0000\u0000\u018b\u018c\u0001\u0000\u0000\u0000\u018c\u018e\u0001\u0000"+
		"\u0000\u0000\u018d\u018b\u0001\u0000\u0000\u0000\u018e\u018f\u0005\u0007"+
		"\u0000\u0000\u018fE\u0001\u0000\u0000\u0000\u0190\u0191\u00056\u0000\u0000"+
		"\u0191\u0192\u0005$\u0000\u0000\u0192\u0197\u00057\u0000\u0000\u0193\u0194"+
		"\u0005\t\u0000\u0000\u0194\u0196\u00057\u0000\u0000\u0195\u0193\u0001"+
		"\u0000\u0000\u0000\u0196\u0199\u0001\u0000\u0000\u0000\u0197\u0195\u0001"+
		"\u0000\u0000\u0000\u0197\u0198\u0001\u0000\u0000\u0000\u0198\u019a\u0001"+
		"\u0000\u0000\u0000\u0199\u0197\u0001\u0000\u0000\u0000\u019a\u019b\u0005"+
		"$\u0000\u0000\u019b\u019c\u00056\u0000\u0000\u019cG\u0001\u0000\u0000"+
		"\u0000\u019d\u019e\u00056\u0000\u0000\u019e\u019f\u0005\n\u0000\u0000"+
		"\u019f\u01a0\u0007\u0000\u0000\u0000\u01a0\u01a1\u0005\r\u0000\u0000\u01a1"+
		"\u01a2\u0007\u0001\u0000\u0000\u01a2\u01a3\u0005\u0010\u0000\u0000\u01a3"+
		"\u01a4\u0005\u0007\u0000\u0000\u01a4I\u0001\u0000\u0000\u0000\u01a5\u01a6"+
		"\u0005%\u0000\u0000\u01a6\u01ab\u00056\u0000\u0000\u01a7\u01a8\u0005\t"+
		"\u0000\u0000\u01a8\u01aa\u00056\u0000\u0000\u01a9\u01a7\u0001\u0000\u0000"+
		"\u0000\u01aa\u01ad\u0001\u0000\u0000\u0000\u01ab\u01a9\u0001\u0000\u0000"+
		"\u0000\u01ab\u01ac\u0001\u0000\u0000\u0000\u01ac\u01ae\u0001\u0000\u0000"+
		"\u0000\u01ad\u01ab\u0001\u0000\u0000\u0000\u01ae\u01af\u0005\u0007\u0000"+
		"\u0000\u01afK\u0001\u0000\u0000\u0000\u01b0\u01b1\u0003^/\u0000\u01b1"+
		"\u01b2\u00056\u0000\u0000\u01b2M\u0001\u0000\u0000\u0000\u01b3\u01b4\u0005"+
		"&\u0000\u0000\u01b4\u01b5\u0005!\u0000\u0000\u01b5\u01ba\u00057\u0000"+
		"\u0000\u01b6\u01b7\u0005\t\u0000\u0000\u01b7\u01b9\u00057\u0000\u0000"+
		"\u01b8\u01b6\u0001\u0000\u0000\u0000\u01b9\u01bc\u0001\u0000\u0000\u0000"+
		"\u01ba\u01b8\u0001\u0000\u0000\u0000\u01ba\u01bb\u0001\u0000\u0000\u0000"+
		"\u01bb\u01bd\u0001\u0000\u0000\u0000\u01bc\u01ba\u0001\u0000\u0000\u0000"+
		"\u01bd\u01be\u0005\"\u0000\u0000\u01beO\u0001\u0000\u0000\u0000\u01bf"+
		"\u01c0\u0005\'\u0000\u0000\u01c0\u01c1\u00056\u0000\u0000\u01c1\u01c2"+
		"\u0005\t\u0000\u0000\u01c2\u01c3\u00056\u0000\u0000\u01c3\u01c4\u0005"+
		"(\u0000\u0000\u01c4Q\u0001\u0000\u0000\u0000\u01c5\u01c8\u0003T*\u0000"+
		"\u01c6\u01c8\u0003V+\u0000\u01c7\u01c5\u0001\u0000\u0000\u0000\u01c7\u01c6"+
		"\u0001\u0000\u0000\u0000\u01c8S\u0001\u0000\u0000\u0000\u01c9\u01ca\u0005"+
		"\u0017\u0000\u0000\u01ca\u01cb\u0003X,\u0000\u01cb\u01cc\u0005\t\u0000"+
		"\u0000\u01cc\u01cd\u0003X,\u0000\u01cd\u01ce\u0005\u0018\u0000\u0000\u01ce"+
		"U\u0001\u0000\u0000\u0000\u01cf\u01d0\u0005\u0017\u0000\u0000\u01d0\u01d1"+
		"\u0003X,\u0000\u01d1\u01d2\u0005)\u0000\u0000\u01d2\u01d3\u0003X,\u0000"+
		"\u01d3\u01d4\u0005\u0018\u0000\u0000\u01d4W\u0001\u0000\u0000\u0000\u01d5"+
		"\u01d6\u0006,\uffff\uffff\u0000\u01d6\u01d7\u0005\u0017\u0000\u0000\u01d7"+
		"\u01d8\u0003X,\u0000\u01d8\u01d9\u0005\u0018\u0000\u0000\u01d9\u01e0\u0001"+
		"\u0000\u0000\u0000\u01da\u01db\u0007\u0003\u0000\u0000\u01db\u01e0\u0003"+
		"X,\u0004\u01dc\u01e0\u0003\\.\u0000\u01dd\u01e0\u0003R)\u0000\u01de\u01e0"+
		"\u00056\u0000\u0000\u01df\u01d5\u0001\u0000\u0000\u0000\u01df\u01da\u0001"+
		"\u0000\u0000\u0000\u01df\u01dc\u0001\u0000\u0000\u0000\u01df\u01dd\u0001"+
		"\u0000\u0000\u0000\u01df\u01de\u0001\u0000\u0000\u0000\u01e0\u01e9\u0001"+
		"\u0000\u0000\u0000\u01e1\u01e2\n\u0006\u0000\u0000\u01e2\u01e3\u0007\u0004"+
		"\u0000\u0000\u01e3\u01e8\u0003X,\u0007\u01e4\u01e5\n\u0005\u0000\u0000"+
		"\u01e5\u01e6\u0007\u0003\u0000\u0000\u01e6\u01e8\u0003X,\u0006\u01e7\u01e1"+
		"\u0001\u0000\u0000\u0000\u01e7\u01e4\u0001\u0000\u0000\u0000\u01e8\u01eb"+
		"\u0001\u0000\u0000\u0000\u01e9\u01e7\u0001\u0000\u0000\u0000\u01e9\u01ea"+
		"\u0001\u0000\u0000\u0000\u01eaY\u0001\u0000\u0000\u0000\u01eb\u01e9\u0001"+
		"\u0000\u0000\u0000\u01ec\u01ef\u0003\\.\u0000\u01ed\u01ef\u00056\u0000"+
		"\u0000\u01ee\u01ec\u0001\u0000\u0000\u0000\u01ee\u01ed\u0001\u0000\u0000"+
		"\u0000\u01ef[\u0001\u0000\u0000\u0000\u01f0\u01f1\u0007\u0005\u0000\u0000"+
		"\u01f1]\u0001\u0000\u0000\u0000\u01f2\u01f8\u0005.\u0000\u0000\u01f3\u01f5"+
		"\u0005/\u0000\u0000\u01f4\u01f3\u0001\u0000\u0000\u0000\u01f4\u01f5\u0001"+
		"\u0000\u0000\u0000\u01f5\u01f6\u0001\u0000\u0000\u0000\u01f6\u01f8\u0005"+
		"0\u0000\u0000\u01f7\u01f2\u0001\u0000\u0000\u0000\u01f7\u01f4\u0001\u0000"+
		"\u0000\u0000\u01f8_\u0001\u0000\u0000\u0000*dinsx\u0088\u008d\u0095\u009c"+
		"\u00a7\u00b2\u00b5\u00dc\u00de\u00f2\u00fb\u010c\u0119\u011e\u0122\u012d"+
		"\u0135\u0148\u014c\u014e\u015e\u0162\u0167\u0174\u0178\u0180\u018b\u0197"+
		"\u01ab\u01ba\u01c7\u01df\u01e7\u01e9\u01ee\u01f4\u01f7";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}