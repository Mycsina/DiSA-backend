import logging
import math
import sys
from enum import Enum

import cv2 as cv
import numpy as np


class Align(Enum):
    CENTERED = 0
    LEFT = 1
    RIGHT = 2
    ABOVE = 3
    BELOW = 4
    TOP_LEFT = 5
    TOP_RIGHT = 6
    BOTTOM_LEFT = 7
    BOTTOM_RIGHT = 8


class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __add__(self, other):
        return Point(self.x + other.x, self.y + other.y)

    def __sub__(self, other):
        return Point(self.x - other.x, self.y - other.y)

    def __mul__(self, scalar):
        return Point(self.x * scalar, self.y * scalar)

    def __truediv__(self, scalar):
        return Point(self.x / scalar, self.y / scalar)

    def __floordiv__(self, scalar):
        return Point(self.x // scalar, self.y // scalar)

    def __str__(self):
        return "(" + str(self.x) + "," + str(self.y) + ")"

    def round_to_int(self):
        return (int(round(self.x)), int(round(self.y)))

    def norm(self):
        return math.sqrt(self.x**2 + self.y**2)


class State:
    def __init__(self, label):
        self.label = label
        self.initial = False
        self.accepting = False
        self.transitions = {}

    def add_transition(self, state, symbol):
        if state not in self.transitions:
            self.transitions[state] = [symbol]
        else:
            self.transitions[state].append(symbol)

    def __str__(self):
        res = f"State({self.label})"
        if self.initial:
            res += " [initial]"
        return res + str(self.transitions)

    def __repr__(self):
        return self.__str__()


class AdvAutomatonView:
    def __init__(self, name):
        self.name = name
        self.figures = {}

    def add_figure(self, key, figure):
        self.figures[key] = figure

    def draw(self, mat, scale_from, scale_to):
        for f in self.figures.values():
            f.draw(mat, scale_from, scale_to)


class AdvFigure:
    def __init__(self, key):
        self.key = key
        self.reference_point = Point(0, 0)
        self.visible = False
        self.stroke_color = (0, 0, 0)
        self.stroke_thickness = 2

    def draw(self, mat, scale_from, scale_to):
        # to be overwritten by subclasses
        pass


class AdvTransitionFigure(AdvFigure):
    def __init__(self, key, label):
        super().__init__(key)
        self.label = label
        self.labelreference_point = Point(0, 0)
        self.label_alignment = Align.CENTERED
        self.arrow_points = []

    def draw(self, mat, scale_from, scale_to):
        # if not visible do nothing
        if not self.visible:
            return

        print("  Drawing transition " + self.key)

        # convert arrow's points to image coordinates
        points = []
        for p in self.arrow_points:
            p1 = p / scale_from * scale_to
            points.append(p1.round_to_int())

        print(points)
        # draw the arrow, assuming there are at least 2 points
        for i, p in enumerate(points[:-2]):
            cv.line(mat, p, points[i + 1], self.stroke_color, self.stroke_thickness)
        cv.arrowedLine(mat, points[-2], points[-1], self.stroke_color, self.stroke_thickness)

    def redefine_arrow_points(self, *points):
        self.arrow_points = []
        for p in points:
            self.arrow_points.append(p)


    def adjust_label_position(self, label_alignment, sz):
        if label_alignment == Align.BELOW:
            return Point(0, sz[1] * 0.75)
        elif label_alignment == Align.ABOVE:
            return Point(0, -sz[1] * 0.75)
        elif label_alignment == Align.LEFT:
            return Point(-sz[0] * 0.75, 0)
        elif label_alignment == Align.RIGHT:
            return Point(sz[0] * 0.75, 0)
        elif label_alignment == Align.TOP_LEFT:
            return Point(-sz[0] * 0.75, -sz[1] * 0.75)
        elif label_alignment == Align.TOP_RIGHT:
            return Point(sz[0] * 0.75, -sz[1] * 0.75)
        elif label_alignment == Align.BOTTOM_LEFT:
            return Point(-sz[0] * 0.75, sz[1] * 0.75)
        elif label_alignment == Align.BOTTOM_RIGHT:
            return Point(sz[0] * 0.75, sz[1] * 0.75)
        return Point(0, 0)


class AdvLineTransitionFigure(AdvTransitionFigure):
    def __init__(self, key, label, *points):
        super().__init__(key, label)

        # for p in points
        if len(points) == 2:
            p1 = points[0]
            p2 = points[1]
            # set arrow points
            p21 = p2 - p1
            d = p21 / p21.norm() * 0.7
            pa = p1 + d
            self.arrow_points.append(pa)
            pb = p2 - d
            self.arrow_points.append(pb)
            p = (pa + pb) / 2 + Point(0, -0.2)
        else:
            self.redefine_arrow_points(*points)
            # find the middle point
            p = Point(0, 0)
            for p1 in self.arrow_points:
                p += p1
            p /= len(self.arrow_points)
        self.labelreference_point = p

    def draw(self, mat, scale_from, scale_to):
        # if not visible do nothing
        if not self.visible:
            return

        print("  Drawing transition " + self.key)

        # convert arrow's points to image coordinates
        points = []
        for p in self.arrow_points:
            p1 = p / scale_from * scale_to
            points.append(p1.round_to_int())

        print(points)
        # draw the arrow, assuming there are at least 2 points
        for i in range(len(points) - 1):
            cv.line(mat, points[i], points[i + 1], self.stroke_color, self.stroke_thickness)
        cv.arrowedLine(mat, points[-2], points[-1], self.stroke_color, self.stroke_thickness)

        # draw the label according to the alignment
        sz, _ = cv.getTextSize(self.label, cv.FONT_HERSHEY_SIMPLEX, 0.6, self.stroke_thickness)
        c = self.labelreference_point / scale_from * scale_to + Point(-sz[0] / 2, sz[1] / 2)
        c += self.adjust_label_position(self.label_alignment, sz)
        center = c.round_to_int()
        cv.putText(mat, self.label, center, cv.FONT_HERSHEY_SIMPLEX, 0.6, self.stroke_thickness)


class AdvLoopTransitionFigure(AdvTransitionFigure):
    def __init__(self, key, label, *p):
        super().__init__(key, label)
        if len(p) == 1:
            # set arrow points
            p1 = p[0] + Point(-0.2, -0.6)
            self.arrow_points.append(p1)
            p1 = p1 + Point(-0.2, -0.3)
            start_mid_point = Point(0, 0) + p1
            self.arrow_points.append(p1)
            p1 = p1 + Point(0.8, 0.0)
            self.arrow_points.append(p1)
            end_mid_point = Point(0, 0) + p1
            p1 = p1 + Point(-0.2, 0.3)
            self.arrow_points.append(p1)

            # set label reference point and alignment
            self.labelreference_point = (start_mid_point + end_mid_point) / 2 + Point(0, 0.1)
            self.label_alignment = Align.CENTERED
        else:
            self.redefine_arrow_points(*p)
            # find the middle point
            p1 = Point(0, 0)
            for p2 in self.arrow_points:
                p1 += p2
            p1 /= len(self.arrow_points)
            self.labelreference_point = p1
            self.label_alignment = Align.CENTERED

    def draw(self, mat, scale_from, scale_to):
        # if not visible do nothing
        if not self.visible:
            return

        print("  Drawing transition " + self.key)

        # convert arrow's points to image coordinates
        points = []
        for p in self.arrow_points:
            p1 = p / scale_from * scale_to
            points.append(p1.round_to_int())

        print(points)
        # draw the arrow, assuming there are at least 2 points
        for i in range(len(points) - 1):
            cv.line(mat, points[i], points[i + 1], self.stroke_color, self.stroke_thickness)
        cv.arrowedLine(mat, points[-2], points[-1], self.stroke_color, self.stroke_thickness)

        # draw the label according to the alignment
        sz, _ = cv.getTextSize(self.label, cv.FONT_HERSHEY_SIMPLEX, 0.6, self.stroke_thickness)
        c = self.labelreference_point / scale_from * scale_to + Point(-sz[0] / 2, sz[1] / 2)
        c += self.adjust_label_position(self.label_alignment, sz)
        center = c.round_to_int()

        cv.putText(mat, self.label, center, cv.FONT_HERSHEY_SIMPLEX, 0.6, self.stroke_thickness)


class AdvStateFigure(AdvFigure):
    def __init__(self, key, origin):
        super().__init__(key)
        self.accepting = False
        self.initial = False
        self.reference_point = origin
        self.transitions = {}
        self.radius = 0.5

    def draw(self, mat, scale_from, scale_to):
        # if not visible do nothing
        if not self.visible:
            return

        print("  Drawing state " + self.key)

        # determine center and radius in image coordinates
        c = self.reference_point / scale_from * scale_to
        center = c.round_to_int()
        r = int(round(self.radius / scale_from * scale_to))

        # draw state shape
        cv.circle(mat, center, r, self.stroke_color, self.stroke_thickness)
        if self.accepting:
            r2 = int(round(0.8 * self.radius / scale_from * scale_to))
            cv.circle(mat, center, r2, self.stroke_color, self.stroke_thickness)
        if self.initial:
            p2 = self.reference_point - Point(self.radius, 0)
            p1 = self.reference_point - Point(self.radius * 3, 0)
            p21 = p2 - p1
            d = p21 / p21.norm() * 0.9
            pa = p1 + d
            points = []
            points.append((pa / scale_from * scale_to).round_to_int())
            pb = p2 - d
            points.append((pb / scale_from * scale_to).round_to_int())
            for i, p in enumerate(points[:-2]):
                cv.line(mat, p, points[i + 1], self.stroke_color, self.stroke_thickness)
            cv.arrowedLine(mat, points[-1], points[-2], self.stroke_color, self.stroke_thickness)

        # draw label
        sz, _ = cv.getTextSize(self.key, cv.FONT_HERSHEY_SIMPLEX, 0.6, self.stroke_thickness)
        c = c + Point(-sz[0] / 2, sz[1] / 2)
        center = c.round_to_int()
        cv.putText(mat, self.key, center, cv.FONT_HERSHEY_SIMPLEX, 0.6, self.stroke_thickness)


class Automaton:
    def __init__(self, name, automaton_type):
        self.name = name
        self.automaton_type = automaton_type
        self.states = {}

    def add_state(self, label):
        self.states[label] = State(label)

    def __str__(self):
        return f"Automaton({self.name}, {self.automaton_type}, {self.states})"

    def __repr__(self):
        return self.__str__()


class Viewport:
    def __init__(self, name, view, bound_x, bound_y, width, height):
        self.name = name
        self.view = view
        self.bound_x = bound_x
        self.bound_y = bound_y
        self.width = width
        self.height = height


# START OF FILE
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s,%(msecs)03d: %(module)17s->%(funcName)-15s - [%(levelname)7s] - %(message)s",
    handlers=[logging.StreamHandler(stream=sys.stdout)],
)

logger = logging.getLogger().getChild("System")
automata = {}
views = {}
grids = {}
defined_alignments = {}

COLOR_STRING_TO_TUPLE = {
    "black": (0, 0, 0),
    "white": (255, 255, 255),
    "red": (0, 0, 255),
    "green": (0, 255, 0),
    "blue": (255, 0, 0),
    "yellow": (0, 255, 255),
    "cyan": (255, 255, 0),
    "gray": (128, 128, 128),
    "orange": (0, 165, 255),
    "brown": (42, 42, 165),
    "purple": (128, 0, 128),
    "pink": (203, 192, 255),
}

def draw_grid(img, grid_shape, color=(0, 255, 0), margin=12, step=25, line_type="solid", thickness=1):
    h, w, _ = img.shape
    start_x, start_y = grid_shape

    # draw vertical lines
    for x in range(margin + start_x, w - margin, step):
        x = int(round(x))
        if line_type == "dotted":
            for xy in range(h - margin - start_y - margin):
                if xy % 3 == 0:
                    cv.line(
                        img,
                        (x, start_y + margin + xy),
                        (x, start_y + margin + xy + 1),
                        color=color,
                        thickness=thickness,
                        lineType=cv.LINE_AA,
                    )
        elif line_type == "dashed":
            for xy in range(h - margin - start_y - margin):
                if xy % 10 == 0:
                    cv.line(
                        img,
                        (x, start_y + margin + xy),
                        (x, start_y + margin + xy + 5),
                        color=color,
                        thickness=thickness,
                        lineType=cv.LINE_AA,
                    )
        else:
            cv.line(img, (x, start_y + margin), (x, h - margin), color=color, thickness=thickness, lineType=cv.LINE_8)

    # draw horizontal lines
    for y in range(margin + start_y, h - margin, step):
        y = int(round(y))
        if line_type == "dotted":
            for xy in range(w - margin - start_x - margin):
                if xy % 3 == 0:
                    cv.line(
                        img,
                        (start_x + margin + xy, y),
                        (start_x + margin + xy + 1, y),
                        color=color,
                        thickness=thickness,
                        lineType=cv.LINE_AA,
                    )
        elif line_type == "dashed":
            for xy in range(w - margin - start_x - margin):
                if xy % 10 == 0:
                    cv.line(
                        img,
                        (start_x + margin + xy, y),
                        (start_x + margin + xy + 5, y),
                        color=color,
                        thickness=thickness,
                        lineType=cv.LINE_AA,
                    )
        else:
            cv.line(img, (start_x + margin, y), (w - margin, y), color=color, thickness=thickness, lineType=cv.LINE_8)


# alphabet = set(['a', 'b', 'c'])

automaton_name = "a3"
automata[automaton_name] = Automaton(automaton_name, "completeDFA")

automata[automaton_name].add_state("A")
automata[automaton_name].add_state("B")
automata[automaton_name].add_state("C")
automata[automaton_name].add_state("D")
automata[automaton_name].add_state("E")
automata[automaton_name].states["A"].initial = True
automata[automaton_name].states["A"].accepting = True
automata[automaton_name].states["B"].accepting = True
automata[automaton_name].states["D"].accepting = True
automata[automaton_name].states["A"].add_transition("B", 'a')
automata[automaton_name].states["B"].add_transition("C", 'b')
automata[automaton_name].states["C"].add_transition("D", 'c')
automata[automaton_name].states["C"].add_transition("E", 'a')
automata[automaton_name].states["C"].add_transition("E", 'b')
automata[automaton_name].states["E"].add_transition("E", 'a')
automata[automaton_name].states["E"].add_transition("E", 'b')
automata[automaton_name].states["E"].add_transition("E", 'c')
automata[automaton_name].states["B"].add_transition("B", 'a')
automata[automaton_name].states["B"].add_transition("A", 'c')
automata[automaton_name].states["A"].add_transition("A", 'c')
automata[automaton_name].states["D"].add_transition("D", 'c')
automata[automaton_name].states["D"].add_transition("B", 'a')
automata[automaton_name].states["D"].add_transition("E", 'b')
automata[automaton_name].states["A"].add_transition("E", 'b')

# view v3 of a3
view_name = "v3"
automaton_name = "a3"
views[view_name] = AdvAutomatonView(view_name)

# grid width 21 height10 y
grids["g3"] = {"width": 21, "height": 10, "color": "gray", "margin": int(0.25 * 50), "step": int(0.5 * 50), "line_type": "solid"}

# A
state_name = "A"
f = AdvStateFigure(state_name, Point(2.0, 1.0))
f.initial = automata[automaton_name].states[state_name].initial
f.accepting = automata[automaton_name].states[state_name].accepting
f.transitions = automata[automaton_name].states[state_name].transitions
views[view_name].add_figure(state_name, f)

# B
state_name = "B"
f = AdvStateFigure(state_name, Point(5.0, 1.0))
f.initial = automata[automaton_name].states[state_name].initial
f.accepting = automata[automaton_name].states[state_name].accepting
f.transitions = automata[automaton_name].states[state_name].transitions
views[view_name].add_figure(state_name, f)

# C
state_name = "C"
f = AdvStateFigure(state_name, Point(7.0, 1.0))
f.initial = automata[automaton_name].states[state_name].initial
f.accepting = automata[automaton_name].states[state_name].accepting
f.transitions = automata[automaton_name].states[state_name].transitions
views[view_name].add_figure(state_name, f)

# D
state_name = "D"
f = AdvStateFigure(state_name, Point(10.0, 1.0))
f.initial = automata[automaton_name].states[state_name].initial
f.accepting = automata[automaton_name].states[state_name].accepting
f.transitions = automata[automaton_name].states[state_name].transitions
views[view_name].add_figure(state_name, f)

# E
state_name = "E"
f = AdvStateFigure(state_name, Point(4.5, 4.0))
f.initial = automata[automaton_name].states[state_name].initial
f.accepting = automata[automaton_name].states[state_name].accepting
f.transitions = automata[automaton_name].states[state_name].transitions
views[view_name].add_figure(state_name, f)

# redefine transition <B,A> to (4.388691891950204, 1.3410313725049041)(3.5, 1.5)(2.6390616755093395, 1.2856574432693744)
points = [Point(4.388691891950204, 1.3410313725049041), Point(3.5, 1.5), Point(2.6390616755093395, 1.2856574432693744)]
if "<B,A>" not in views[view_name].figures:
    f = AdvLineTransitionFigure("<B,A>", "", *points)
    views[view_name].add_figure("<B,A>", f)
else:
    views[view_name].figures["<B,A>"].arrow_points = points[:]

if "<B,A>" in defined_alignments:
    views[view_name].figures["<B,A>"].label_alignment = defined_alignments["<B,A>"]


# <B,A>#label [align=above];
defined_alignments["<B,A>"] = Align.ABOVE

# place <B,A>#label [align = above] at (3.5, 1.5);
pa = Point(3.5, 1.5)
if "<B,A>" in views[view_name].figures:

    views[view_name].figures["<B,A>"].label_alignment = Align.ABOVE
    views[view_name].figures["<B,A>"].labelreference_point = pa
else:
    f = AdvLineTransitionFigure("<B,A>", "", Point(0,0))
    f.label_alignment = Align.ABOVE
    f.labelreference_point = pa
    views[view_name].add_figure("<B,A>", f)

if "<B,A>" in defined_alignments:
    views[view_name].figures["<B,A>"].label_alignment = defined_alignments["<B,A>"]

# redefine transition <D,B> to (9.388691891950204, 1.3410313725049041)(7.5, 2.0)(5.639061675509339, 1.2856574432693744)
points = [Point(9.388691891950204, 1.3410313725049041), Point(7.5, 2.0), Point(5.639061675509339, 1.2856574432693744)]
if "<D,B>" not in views[view_name].figures:
    f = AdvLineTransitionFigure("<D,B>", "", *points)
    views[view_name].add_figure("<D,B>", f)
else:
    views[view_name].figures["<D,B>"].arrow_points = points[:]

if "<D,B>" in defined_alignments:
    views[view_name].figures["<D,B>"].label_alignment = defined_alignments["<D,B>"]


# <D,B>#label [align=above];
defined_alignments["<D,B>"] = Align.ABOVE

# place <D,B>#label [align = above] at (7.5, 2.0);
pa = Point(7.5, 2.0)
if "<D,B>" in views[view_name].figures:

    views[view_name].figures["<D,B>"].label_alignment = Align.ABOVE
    views[view_name].figures["<D,B>"].labelreference_point = pa
else:
    f = AdvLineTransitionFigure("<D,B>", "", Point(0,0))
    f.label_alignment = Align.ABOVE
    f.labelreference_point = pa
    views[view_name].add_figure("<D,B>", f)

if "<D,B>" in defined_alignments:
    views[view_name].figures["<D,B>"].label_alignment = defined_alignments["<D,B>"]

# <A,E>#label [align=below left];
defined_alignments["<A,E>"] = Align.BOTTOM_LEFT

# <D,E>#label [align=below right];
defined_alignments["<D,E>"] = Align.BOTTOM_RIGHT

# <C,E>#label [align=right];
defined_alignments["<C,E>"] = Align.RIGHT

# <E,E>#label [align=left];
defined_alignments["<E,E>"] = Align.LEFT

# animation m3
def animation_m3():
    logger.info("Starting animation m3")
    animation_name = "m3"
    viewports = {}

    # viewport vp3 for v3 at (10,10) -- ++(500,300);
    viewports["vp3"] = Viewport("vp3", views["v3"], 10, 10, 500, 300)

    # on vp3 
    viewport_name = "vp3"
    vp1_bound_x = viewports[viewport_name].bound_x
    vp1_bound_y = viewports[viewport_name].bound_y
    vp1_height = viewports[viewport_name].height
    vp1_width = viewports[viewport_name].width
    view = viewports[viewport_name].view
    window = np.zeros((vp1_bound_y + vp1_height, vp1_bound_x + vp1_width, 3), dtype="uint8")
    window.fill(100)
    vp1 = np.zeros((vp1_height, vp1_width, 3), dtype="uint8")
    vp1.fill(255)

    # show grid g3;
    draw_grid(vp1, (grids["g3"]["width"], grids["g3"]["height"]), COLOR_STRING_TO_TUPLE[grids["g3"]["color"]], margin=grids["g3"]["margin"], step=grids["g3"]["step"], line_type=grids["g3"]["line_type"], thickness=1)

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # pause;
    cv.waitKey(0)

    # show B [accepting = False];
    view.figures["A"].accepting = False

    # show A;
    view.figures["A"].visible = True

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # show B [accepting = False];
    view.figures["B"].accepting = False

    # show B;
    view.figures["B"].visible = True

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # show B [accepting = False];
    view.figures["D"].accepting = False

    # show D;
    view.figures["D"].visible = True

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # show C;
    view.figures["C"].visible = True

    # show line transition <A,B>;
    label = ",".join(view.figures["A"].transitions["B"])
    if "<A,B>" not in view.figures:
        pa = view.figures["A"].reference_point
        pb = view.figures["B"].reference_point
        f = AdvLineTransitionFigure("<A,B>", label, pa, pb)
        views[view_name].add_figure("<A,B>", f)
    else:
        view.figures["<A,B>"].label = label

    if "<A,B>" in defined_alignments:
        views[view_name].figures["<A,B>"].label_alignment = defined_alignments["<A,B>"]

    # show <A,B>;
    view.figures["<A,B>"].visible = True

    # show line transition <B,C>;
    label = ",".join(view.figures["B"].transitions["C"])
    if "<B,C>" not in view.figures:
        pa = view.figures["B"].reference_point
        pb = view.figures["C"].reference_point
        f = AdvLineTransitionFigure("<B,C>", label, pa, pb)
        views[view_name].add_figure("<B,C>", f)
    else:
        view.figures["<B,C>"].label = label

    if "<B,C>" in defined_alignments:
        views[view_name].figures["<B,C>"].label_alignment = defined_alignments["<B,C>"]

    # show <B,C>;
    view.figures["<B,C>"].visible = True

    # show line transition <C,D>;
    label = ",".join(view.figures["C"].transitions["D"])
    if "<C,D>" not in view.figures:
        pa = view.figures["C"].reference_point
        pb = view.figures["D"].reference_point
        f = AdvLineTransitionFigure("<C,D>", label, pa, pb)
        views[view_name].add_figure("<C,D>", f)
    else:
        view.figures["<C,D>"].label = label

    if "<C,D>" in defined_alignments:
        views[view_name].figures["<C,D>"].label_alignment = defined_alignments["<C,D>"]

    # show <C,D>;
    view.figures["<C,D>"].visible = True

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # pause;
    cv.waitKey(0)

    # show E;
    view.figures["E"].visible = True

    # show line transition <C,E>;
    label = ",".join(view.figures["C"].transitions["E"])
    if "<C,E>" not in view.figures:
        pa = view.figures["C"].reference_point
        pb = view.figures["E"].reference_point
        f = AdvLineTransitionFigure("<C,E>", label, pa, pb)
        views[view_name].add_figure("<C,E>", f)
    else:
        view.figures["<C,E>"].label = label

    if "<C,E>" in defined_alignments:
        views[view_name].figures["<C,E>"].label_alignment = defined_alignments["<C,E>"]

    # show <C,E>;
    view.figures["<C,E>"].visible = True

    # show loop transition <E,E>;
    label = ",".join(view.figures["E"].transitions["E"])
    if "<E,E>" not in view.figures:
        pa = view.figures["E"].reference_point
        f = AdvLoopTransitionFigure("<E,E>", label, pa)
        views[view_name].add_figure("<E,E>", f)
    else:
        view.figures["<E,E>"].label = label

    if "<E,E>" in defined_alignments:
        views[view_name].figures["<E,E>"].label_alignment = defined_alignments["<E,E>"]

    # show <E,E>;
    view.figures["<E,E>"].visible = True

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # pause;
    cv.waitKey(0)

    # show loop transition <B,B>;
    label = ",".join(view.figures["B"].transitions["B"])
    if "<B,B>" not in view.figures:
        pa = view.figures["B"].reference_point
        f = AdvLoopTransitionFigure("<B,B>", label, pa)
        views[view_name].add_figure("<B,B>", f)
    else:
        view.figures["<B,B>"].label = label

    if "<B,B>" in defined_alignments:
        views[view_name].figures["<B,B>"].label_alignment = defined_alignments["<B,B>"]

    # show <B,B>;
    view.figures["<B,B>"].visible = True

    # show line transition <B,A>;
    label = ",".join(view.figures["B"].transitions["A"])
    if "<B,A>" not in view.figures:
        pa = view.figures["B"].reference_point
        pb = view.figures["A"].reference_point
        f = AdvLineTransitionFigure("<B,A>", label, pa, pb)
        views[view_name].add_figure("<B,A>", f)
    else:
        view.figures["<B,A>"].label = label

    if "<B,A>" in defined_alignments:
        views[view_name].figures["<B,A>"].label_alignment = defined_alignments["<B,A>"]

    # show <B,A>;
    view.figures["<B,A>"].visible = True

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # pause;
    cv.waitKey(0)

    # show loop transition <A,A>;
    label = ",".join(view.figures["A"].transitions["A"])
    if "<A,A>" not in view.figures:
        pa = view.figures["A"].reference_point
        f = AdvLoopTransitionFigure("<A,A>", label, pa)
        views[view_name].add_figure("<A,A>", f)
    else:
        view.figures["<A,A>"].label = label

    if "<A,A>" in defined_alignments:
        views[view_name].figures["<A,A>"].label_alignment = defined_alignments["<A,A>"]

    # show <A,A>;
    view.figures["<A,A>"].visible = True

    # show line transition <A,E>;
    label = ",".join(view.figures["A"].transitions["E"])
    if "<A,E>" not in view.figures:
        pa = view.figures["A"].reference_point
        pb = view.figures["E"].reference_point
        f = AdvLineTransitionFigure("<A,E>", label, pa, pb)
        views[view_name].add_figure("<A,E>", f)
    else:
        view.figures["<A,E>"].label = label

    if "<A,E>" in defined_alignments:
        views[view_name].figures["<A,E>"].label_alignment = defined_alignments["<A,E>"]

    # show <A,E>;
    view.figures["<A,E>"].visible = True

    # show loop transition <D,D>;
    label = ",".join(view.figures["D"].transitions["D"])
    if "<D,D>" not in view.figures:
        pa = view.figures["D"].reference_point
        f = AdvLoopTransitionFigure("<D,D>", label, pa)
        views[view_name].add_figure("<D,D>", f)
    else:
        view.figures["<D,D>"].label = label

    if "<D,D>" in defined_alignments:
        views[view_name].figures["<D,D>"].label_alignment = defined_alignments["<D,D>"]

    # show <D,D>;
    view.figures["<D,D>"].visible = True

    # show line transition <D,E>;
    label = ",".join(view.figures["D"].transitions["E"])
    if "<D,E>" not in view.figures:
        pa = view.figures["D"].reference_point
        pb = view.figures["E"].reference_point
        f = AdvLineTransitionFigure("<D,E>", label, pa, pb)
        views[view_name].add_figure("<D,E>", f)
    else:
        view.figures["<D,E>"].label = label

    if "<D,E>" in defined_alignments:
        views[view_name].figures["<D,E>"].label_alignment = defined_alignments["<D,E>"]

    # show <D,E>;
    view.figures["<D,E>"].visible = True

    # show line transition <D,B>;
    label = ",".join(view.figures["D"].transitions["B"])
    if "<D,B>" not in view.figures:
        pa = view.figures["D"].reference_point
        pb = view.figures["B"].reference_point
        f = AdvLineTransitionFigure("<D,B>", label, pa, pb)
        views[view_name].add_figure("<D,B>", f)
    else:
        view.figures["<D,B>"].label = label

    if "<D,B>" in defined_alignments:
        views[view_name].figures["<D,B>"].label_alignment = defined_alignments["<D,B>"]

    # show <D,B>;
    view.figures["<D,B>"].visible = True

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # pause;
    cv.waitKey(0)

    # show B [accepting = True];
    view.figures["A"].accepting = True

    # show A;
    view.figures["A"].visible = True

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # show B [accepting = True];
    view.figures["B"].accepting = True

    # show B;
    view.figures["B"].visible = True

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # show B [accepting = True];
    view.figures["D"].accepting = True

    # show D;
    view.figures["D"].visible = True

    # post show
    view.draw(vp1, 1.0, 50)
    np.copyto(window[vp1_bound_y:, vp1_bound_x:, :], vp1)
    cv.imshow(f"Animation {animation_name} - Viewport {viewport_name}", window)

    # pause;
    cv.waitKey(0)

# play m3;
animation_m3()